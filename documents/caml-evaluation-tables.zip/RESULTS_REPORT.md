# CAML-Net: actual research prototype results

Newly trained architecture; these are not renamed v2 results. Open-I labels are report-derived weak mappings. The reused IU test partition was previously inspected; results are exploratory.
Actual environment: cuda. Training seeds: [11, 22, 33]. Trained observations: 14/14.
MIMIC-CXR final evaluation and executed Colab GPU results are not supplied unless this run actually used those inputs/runtime. No clinical conflict or hallucination-prevention guarantee is established.

| Model | AUROC | Macro AP | Micro F1 | Brier | ECE |
|---|---:|---:|---:|---:|---:|
| image | 0.75185 | 0.17193 | 0.38280 | 0.04384 | 0.00842 |
| text | 0.95318 | 0.64655 | 0.82602 | 0.01627 | 0.00470 |
| concat | 0.95357 | 0.55405 | 0.80336 | 0.01795 | 0.00550 |
| full | 0.93759 | 0.56029 | 0.82034 | 0.01622 | 0.00327 |
| no_cross_attention | 0.93602 | 0.52445 | 0.81544 | 0.01721 | 0.00372 |
| no_conflict_gate | 0.93700 | 0.57281 | 0.79931 | 0.01816 | 0.00390 |
| no_private | 0.93612 | 0.51013 | 0.81443 | 0.01654 | 0.00466 |
| no_mse | 0.93797 | 0.51851 | 0.82524 | 0.01645 | 0.00458 |
| no_kl | 0.92898 | 0.52316 | 0.80412 | 0.01779 | 0.00289 |

Conditional group-bootstrap intervals and paired Holm-adjusted permutation tests are in the supplied JSON files. A single seed has no training-seed SD; missingness-draw SD measures masking variability only.

## Report missingness

| Rate | Mean AUROC | Mean micro F1 | Mean Brier |
|---|---:|---:|---:|
| 0% | 0.93759 | 0.82034 | 0.01622 |
| 20% | 0.90584 | 0.74546 | 0.02200 |
| 40% | 0.87786 | 0.66547 | 0.02808 |
| 60% | 0.83764 | 0.59008 | 0.03374 |
| 80% | 0.80109 | 0.50368 | 0.03892 |

## Scope

Fourteen targets are the CheXpert-compatible observations, including No Finding and Support Devices, not fourteen exclusively named diseases. Open-I mappings are transparent approximations; masked unknown/unsupported outputs are not fabricated trained classifiers.
Each finding has an independent binary Dirichlet/Beta head. Calibrated probabilities use held-out temperature scaling; raw evidence strengths and vacuity/MI remain proxies. Evidence calibration and clinical triage are not established by a low probability ECE.
Native paired inputs are weakly presumed concordant when no pair_concordant annotation column is supplied. Explicit conflict or unknown pairs in that column are excluded from shared-feature MSE.
Conflict scores are feature-discrepancy proxies. Controlled differing-label report swaps do not establish actual clinical contradiction detection or identify the correct source.
Linear shared/private orthogonalization is implemented; semantic/causal identifiability of disentangled factors is not established.
