import unittest,tempfile,json
from pathlib import Path
from dataclasses import asdict
import torch
import numpy as np
from caml.model import CAMLNet,evidence,wrong_evidence_kl,orthogonal_private,total_loss
from caml.data import mesh_positive,manifest_labels,LABELS,weak_iu_labels
from caml.iu_io import Study
from caml.engine import restore,triage
from caml.statistics import holm_adjust,bootstrap_paired


class CAMLTests(unittest.TestCase):
 def setUp(self):torch.set_num_threads(2);torch.manual_seed(9)
 def inputs(self):
  return [torch.randn(3,32,10),torch.randn(3,12,8),torch.ones(3,32,dtype=torch.bool),torch.ones(3,12,dtype=torch.bool)]
 def model(self,mode='full'):return CAMLNet(10,8,14,mode,max_text=12)

 def test_fourteen_independent_binary_dirichlets(self):
  r=evidence(torch.zeros(2,14,2));self.assertEqual(r['alpha'].shape,(2,14,2))
  self.assertTrue((r['alpha']>=1).all());self.assertTrue(torch.allclose(r['probability'].sum(1),torch.full((2,),7.)))
 def test_beta_probability_and_uncertainty_identity(self):
  r=evidence(torch.randn(2,14,2));a=r['alpha']
  self.assertTrue(torch.allclose(r['probability'],a[:,:,1]/a.sum(-1)))
  self.assertTrue(torch.allclose(r['vacuity'],2/a.sum(-1)))
  self.assertTrue((r['epistemic_mi_proxy']>=0).all())
 def test_kl_uniform_zero_and_correct_evidence_removed(self):
  y=torch.tensor([[1.,0.]])
  a=torch.tensor([[[1.,20.],[20.,1.]]])
  self.assertTrue(torch.allclose(wrong_evidence_kl(a,y),torch.zeros(1,2),atol=1e-6))
  bad=torch.tensor([[[20.,1.],[1.,20.]]]);self.assertTrue((wrong_evidence_kl(bad,y)>0).all())
 def test_512_dimensions_and_orthogonal_private(self):
  m=self.model().eval();r=m(*self.inputs())
  self.assertEqual(r['image_embedding'].shape,(3,512));self.assertEqual(r['text_embedding'].shape,(3,512))
  dot=(r['private_image']*r['shared_image']).sum(-1)
  self.assertTrue(torch.allclose(dot,torch.zeros_like(dot),atol=1e-4))
 def test_cosine_discrepancy_score_bounded(self):
  r=self.model().eval()(*self.inputs());self.assertTrue(((r['conflict']>=0)&(r['conflict']<=1)).all())
  self.assertTrue(((r['cosine']>=-1.00001)&(r['cosine']<=1.00001)).all())
 def test_attention_real_token_shapes_and_gradients(self):
  m=self.model().eval();r=m(*self.inputs(),attention=True);self.assertEqual(r['attention'].shape,(3,12,32))
  r['probability'].sum().backward()
  self.assertGreater(float(m.i_to_t.in_proj_weight.grad.abs().sum()),0)
  self.assertGreater(float(m.t_to_i.in_proj_weight.grad.abs().sum()),0)
 def test_missing_report_cannot_leak_context(self):
  m=self.model().eval();a=self.inputs();a[3][:]=False;r=m(*a)
  a[1]*=1000;s=m(*a)
  self.assertTrue(torch.equal(r['probability'],s['probability']))
  self.assertTrue((r['weights'][:,:,1]==0).all());self.assertTrue((r['conflict']==0).all())
 def test_padding_invariance(self):
  m=self.model().eval();a=self.inputs();a[2][:,20:]=False;a[3][:,7:]=False;r=m(*a)['probability']
  a[0][:,20:]=1e4;a[1][:,7:]=-1e4
  self.assertTrue(torch.allclose(r,m(*a)['probability'],atol=1e-6))
 def test_all_missing_forward_finite(self):
  m=self.model();a=self.inputs();a[2][:]=False;a[3][:]=False;r=m(*a)
  self.assertTrue(torch.isfinite(r['probability']).all())
 def test_exact_three_headline_loss_terms(self):
  m=self.model();r=m(*self.inputs());y=torch.randint(0,2,(3,14)).float();y[0,0]=-1
  loss,parts=total_loss(r,y,'full',5,.1,.01)
  self.assertAlmostEqual(float(loss),parts['bce']+.1*parts['shared_mse']+.01*parts['evidential_kl'],places=5)
  loss.backward();self.assertTrue(all(torch.isfinite(p.grad).all() for p in m.parameters() if p.grad is not None))
 def test_explicit_conflicting_pairs_do_not_get_alignment_mse(self):
  r=self.model()(*self.inputs());r['pair'][:]=False
  _,parts=total_loss(r,torch.zeros(3,14),'full',1)
  self.assertEqual(parts['shared_mse'],0)
 def test_kl_and_mse_ablations_remove_terms(self):
  for mode,key in [('no_mse','shared_mse'),('no_kl','evidential_kl')]:
   _,parts=total_loss(self.model(mode)(*self.inputs()),torch.zeros(3,14),mode,5)
   self.assertEqual(parts[key],0)
 def test_no_private_really_zero(self):
  r=self.model('no_private')(*self.inputs());self.assertEqual(float(r['private_image'].abs().sum()),0)
 def test_atelectasis_mapping_regression(self):
  self.assertTrue(mesh_positive(['Pulmonary Atelectasis/lung/base/left'],'Atelectasis'))
  self.assertFalse(mesh_positive(['Lung/hypoinflation'],'Atelectasis'))
 def test_anatomic_relationships_not_lost(self):
  self.assertTrue(mesh_positive(['Thickening/pleura/apex'],'Pleural Other'))
  self.assertFalse(mesh_positive(['Thickening/bronchovascular'],'Pleural Other'))
  self.assertTrue(mesh_positive(['Mediastinum/prominent/mild'],'Enlarged Cardiomediastinum'))
  self.assertFalse(mesh_positive(['Mediastinum/lymph nodes/enlarged'],'Enlarged Cardiomediastinum'))
 def test_mimic_uncertain_and_unmentioned_masked(self):
  r={k:'' for k in LABELS};r['Edema']='-1.0';r['Pneumonia']='1.0';r['Fracture']='0.0'
  y=manifest_labels(r);self.assertEqual(y[LABELS.index('Edema')],-1)
  self.assertEqual(y[LABELS.index('Atelectasis')],-1)
  self.assertEqual(y[LABELS.index('Pneumonia')],1);self.assertEqual(y[LABELS.index('Fracture')],0)
 def test_no_finding_requires_explicit_normal_mesh(self):
  s=[Study('a',[],'',['normal']),Study('b',[],'',['emphysema'])]
  y=weak_iu_labels(s);self.assertEqual(y[0,-1],1);self.assertEqual(y[1,-1],0)
 def test_checkpoint_restore_exact(self):
  m=self.model().eval();a=self.inputs();ref=m(*a)['probability']
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'full.pt';torch.save({'mode':'full','dims':[10,8,14],'max_text':12,'state_dict':m.state_dict(),'normalization':{}},p)
   n,_,_=restore(p);self.assertTrue(torch.equal(ref,n(*a)['probability']))
 def test_triage_missing_modality_forces_uncertainty(self):
  settings={'conflict_high':.8,'conflict_low':.1,'uncertainty_high':.8,'uncertainty_low':.2,'minimum_decision_confidence_high':.9}
  r=triage(np.full((1,14),.01),np.full((1,14),.01),np.array([0.]),np.array([[1,0]],bool),settings,np.ones(14,bool))
  self.assertEqual(r,['High Uncertainty / Conflict'])
 def test_bootstrap_preserves_identical_models(self):
  y=np.array([[1.,0.],[0.,1.]]);p=np.array([[.8,.2],[.2,.8]])
  r=bootstrap_paired(y,{'full':p,'image':p},np.array(['a','b']),30)
  self.assertEqual(r['full_minus_baseline']['image']['brier']['upper'],0)
 def test_holm_known_values(self):np.testing.assert_allclose(holm_adjust([.01,.04,.03]),[.03,.06,.06])


if __name__=='__main__':unittest.main()
