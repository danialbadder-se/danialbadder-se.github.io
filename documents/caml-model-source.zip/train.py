#!/usr/bin/env python3
"""CAML-Net research implementation: Open-I prototype and authorized MIMIC adapter."""
from __future__ import annotations
import argparse,json,hashlib,logging,sys,platform,shutil,zipfile
from pathlib import Path
from dataclasses import asdict
import numpy as np
import torch
from caml.iu_io import dump_json,log_setup,seed_all,file_hash
from caml.data import prepare,LABELS,build_mimic
from caml.encoders import Encoders,extract,choose_views,load_cache,pooled
from caml.model import MODES
from caml.engine import fit,restore,infer,calibrate,evaluate_mode,aggregate
from caml.evaluate import report_missingness,controlled_conflict,plots


def run(args):
    root=Path(args.output);log_setup(root);seed_all(args.split_seed)
    args.device=('cuda' if torch.cuda.is_available() else 'cpu') if args.device=='auto' else args.device
    if args.device=='cuda' and not torch.cuda.is_available():raise ValueError('CUDA GPU unavailable; use CPU or Colab GPU runtime')
    studies,split,y,active=prepare(args)
    source=Path(__file__).resolve().parent
    protocol={'version':'CAML-1.0.0','labels':LABELS,'seeds':args.seeds,'modes':args.modes,'split_seed':args.split_seed,
              'epochs':args.epochs,'batch_size':args.batch_size,'encoder_batch':args.encoder_batch,'learning_rate':args.lr,'lambda_mse':args.lambda_mse,'lambda_kl':args.lambda_kl,
              'kl_anneal_epochs':5,'max_length':args.max_length,'encoder_embedding_dim':512,'attention_bottleneck_dim':64,
              'bootstrap':args.bootstrap,'permutations':args.permutations,
              'source_sha256':{str(p.relative_to(source)):file_hash(p) for p in sorted(source.rglob('*.py')) if '__pycache__' not in p.parts},
              'scope':'Exploratory Open-I weak-label prototype; original IU test split was previously inspected. MIMIC evaluation requires authorized data. Colab GPU execution is not claimed unless separately recorded.',
              'uncertainty':'14 independent two-class Dirichlets/Beta; posthoc temperature calibrates means only; evidence strength not certified epistemic calibration'}
    lock=root/'protocol.json'
    if lock.exists() and json.loads(lock.read_text())!=protocol:raise ValueError('Protocol/source differs; use a fresh output/cache directory')
    dump_json(lock,protocol)
    dump_json(root/'environment.json',{'python':sys.version,'torch':torch.__version__,'device':args.device,'cuda_available':torch.cuda.is_available(),'platform':platform.platform(),'synthetic':False})
    cache_path=Path(args.cache)
    if (cache_path/'complete.json').exists():
        marker=json.loads((cache_path/'complete.json').read_text())
        if marker['signature']!=json.loads((root/'dataset_manifest.json').read_text())['signature']:raise ValueError('Cache belongs to different studies/labels')
        if marker.get('text_encoder')!='dmis-lab/biobert-base-cased-v1.2':raise ValueError('A BioBERT cache is required; do not reuse BiomedBERT text embeddings')
        cache=load_cache(cache_path)
    else:
        enc=root/'shared/encoders'
        if not (enc/'encoder_config.json').exists():Encoders(enc,args.device,download=True,max_length=args.max_length)
        chosen=choose_views(studies,args.data_dir);dump_json(root/'chosen_private.json',chosen)
        cache=extract(studies,chosen,cache_path,enc,json.loads((root/'dataset_manifest.json').read_text())['signature'],args.device,args.encoder_batch,args.max_length)
        marker=json.loads((cache_path/'complete.json').read_text());marker['text_encoder']='dmis-lab/biobert-base-cased-v1.2';dump_json(cache_path/'complete.json',marker)
    pi,pt=pooled(cache);tr=split=='train'
    norm={'mean_i':pi[tr].mean(0),'std_i':pi[tr].std(0).clip(.05),'mean_t':pt[tr].mean(0),'std_t':pt[tr].std(0).clip(.05)}
    np.savez(root/'normalization.npz',**norm)
    indices=np.arange(len(studies))
    for seed in args.seeds:
        folder=root/f'seed_{seed}';folder.mkdir(exist_ok=True)
        for mode in args.modes:
            if (folder/f'{mode}.pt').exists():model,oldnorm,cp=restore(folder/f'{mode}.pt',args.device)
            else:model=fit(cache,y,split,active,norm,mode,seed,args)
            raw=infer(model,cache,indices,norm,args.device,args.batch_size)
            p,settings=calibrate(raw,y,split,active)
            evaluate_mode(raw,p,settings,y,split,active,LABELS,folder,mode)
            logging.info('CAML_MODEL_CHECKPOINT seed=%s mode=%s',seed,mode)
    comparison=aggregate(args,studies,y,split,LABELS)
    missing=report_missingness(args,cache,y,split,studies,active)
    controlled_conflict(args,cache,y,split,studies)
    plots(root,comparison,missing)
    report=['# CAML-Net: actual research prototype results','',
      'Newly trained architecture; these are not renamed v2 results. Open-I labels are report-derived weak mappings. The reused IU test partition was previously inspected; results are exploratory.',
      f'Actual environment: {args.device}. Training seeds: {args.seeds}. Trained observations: {int(active.sum())}/14.',
      'MIMIC-CXR final evaluation and executed Colab GPU results are not supplied unless this run actually used those inputs/runtime. No clinical conflict or hallucination-prevention guarantee is established.','',
      '| Model | AUROC | Macro AP | Micro F1 | Brier | ECE |','|---|---:|---:|---:|---:|---:|']
    for row in comparison:
        report.append('| '+row['model']+' | '+' | '.join('NA' if row[k] is None else f'{row[k]:.5f}' for k in ['macro_auroc','macro_average_precision','micro_f1','brier','pooled_ece_10_bins'])+' |')
    report+=['','Conditional group-bootstrap intervals and paired Holm-adjusted permutation tests are in the supplied JSON files. A single seed has no training-seed SD; missingness-draw SD measures masking variability only.','',
      '## Report missingness','', '| Rate | Mean AUROC | Mean micro F1 | Mean Brier |','|---|---:|---:|---:|']
    for rate in [0,.2,.4,.6,.8]:
        rr=[r for r in missing if r['requested_report_missingness']==rate]
        report.append(f'| {rate:.0%} | '+ ' | '.join(f'{np.mean([r[k] for r in rr]):.5f}' for k in ['macro_auroc','micro_f1','brier'])+' |')
    report+=['','## Scope','',
      'Fourteen targets are the CheXpert-compatible observations, including No Finding and Support Devices, not fourteen exclusively named diseases. Open-I mappings are transparent approximations; masked unknown/unsupported outputs are not fabricated trained classifiers.',
      'Each finding has an independent binary Dirichlet/Beta head. Calibrated probabilities use held-out temperature scaling; raw evidence strengths and vacuity/MI remain proxies. Evidence calibration and clinical triage are not established by a low probability ECE.',
      'Native paired inputs are weakly presumed concordant when no pair_concordant annotation column is supplied. Explicit conflict or unknown pairs in that column are excluded from shared-feature MSE.',
      'Conflict scores are feature-discrepancy proxies. Controlled differing-label report swaps do not establish actual clinical contradiction detection or identify the correct source.',
      'Linear shared/private orthogonalization is implemented; semantic/causal identifiability of disentangled factors is not established.','']
    (root/'RESULTS_REPORT.md').write_text('\n'.join(report),encoding='utf-8')
    logging.info('CAML_NET_REAL_RUN_COMPLETE: %s',root.resolve())


def package(args):
    root=Path(args.run_dir).resolve();code=Path(__file__).resolve().parent
    protocol=json.loads((root/'protocol.json').read_text());required=['missingness_results.json','controlled_conflict.json','model_comparison.csv','bootstrap_95ci.json','permutation_holm.json']
    for rel in required:
        if not (root/rel).is_file():raise FileNotFoundError(rel)
    files=[]
    for p in code.rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts:files.append((p,'CAML_Net/code/'+str(p.relative_to(code))))
    for p in root.rglob('*'):
        if not p.is_file() or p.name.endswith('_private.json') or '__pycache__' in p.parts:continue
        files.append((p,'CAML_Net/run/'+str(p.relative_to(root))))
    manifest=[]
    for seed in protocol['seeds']:
        for mode in protocol['modes']:
            if not (root/f'seed_{seed}/{mode}.pt').is_file():raise FileNotFoundError(f'{seed}/{mode}')
    with zipfile.ZipFile(args.output,'w',zipfile.ZIP_DEFLATED,compresslevel=4,allowZip64=True) as z:
        for p,name in files:manifest.append({'path':name,'sha256':file_hash(p),'bytes':p.stat().st_size});z.write(p,name)
        z.writestr('CAML_Net/SHA256_MANIFEST.json',json.dumps(manifest,indent=2))
        z.writestr('CAML_Net/START_HERE.txt','Read code/README.md and run/RESULTS_REPORT.md. This is a newly trained CAML-Net Open-I prototype, not the old v2 classifier. Exact encoders and checkpoints included. MIMIC-CXR final evaluation and executed Colab GPU results are not provided without authorized data/runtime.\n')
    with zipfile.ZipFile(args.output) as z:assert z.testzip() is None
    print('CAML_PACKAGE_COMPLETE',Path(args.output).resolve(),Path(args.output).stat().st_size)


def main():
    parser=argparse.ArgumentParser(description=__doc__);sub=parser.add_subparsers(dest='command',required=True)
    p=sub.add_parser('run');p.add_argument('--data-dir',required=True);p.add_argument('--manifest');p.add_argument('--reuse-iu-index')
    p.add_argument('--output',default='caml_outputs');p.add_argument('--cache',default='caml_token_cache')
    p.add_argument('--seeds',nargs='+',type=int,default=[11,22,33]);p.add_argument('--modes',nargs='+',choices=MODES,default=MODES)
    p.add_argument('--split-seed',type=int,default=42);p.add_argument('--min-support',type=int,default=5)
    p.add_argument('--epochs',type=int,default=12);p.add_argument('--patience',type=int,default=4);p.add_argument('--batch-size',type=int,default=32)
    p.add_argument('--lr',type=float,default=.001);p.add_argument('--lambda-mse',type=float,default=.1);p.add_argument('--lambda-kl',type=float,default=.01)
    p.add_argument('--max-length',type=int,default=128);p.add_argument('--encoder-batch',type=int,default=8)
    p.add_argument('--bootstrap',type=int,default=1000);p.add_argument('--permutations',type=int,default=2000);p.add_argument('--device',choices=['auto','cpu','cuda'],default='auto')
    p=sub.add_parser('predict');p.add_argument('--run-dir',required=True);p.add_argument('--image',action='append',default=[]);p.add_argument('--report-file');p.add_argument('--output',default='caml_prediction.json');p.add_argument('--device',default='cpu')
    p=sub.add_parser('prepare-mimic');p.add_argument('--data-dir',required=True);p.add_argument('--reports-dir',required=True);p.add_argument('--split-file',required=True);p.add_argument('--label-file',required=True);p.add_argument('--output',default='mimic_manifest.csv')
    p=sub.add_parser('package');p.add_argument('--run-dir',required=True);p.add_argument('--output',default='CAML_Net_Complete.zip')
    args=parser.parse_args()
    if args.command=='run':run(args)
    elif args.command=='predict':
        from caml.inference import predict
        predict(args)
    elif args.command=='prepare-mimic':build_mimic(args)
    elif args.command=='package':package(args)


if __name__=='__main__':main()
