# CAML-Net model source

Core Python source from the recorded Open-I study. The model, data preparation, evaluation and training files were matched to the GPU run protocol by SHA-256. This source download is accompanied by a separate aggregate results package on the portfolio. Training requires the appropriate Open-I data and encoder assets.
