"""CAML-Net: independent binary Dirichlets for co-occurring observations."""
from __future__ import annotations
import torch
from torch import nn
import torch.nn.functional as F

MODES=['image','text','concat','full','no_cross_attention','no_conflict_gate','no_private','no_mse','no_kl']


def mean_tokens(x,mask):return (x*mask[...,None]).sum(1)/mask.sum(1,keepdim=True).clamp_min(1)


def evidence(raw):
    # Last axis [negative,positive], independently for each finding.
    alpha=1+F.softplus(raw)
    strength=alpha.sum(-1);p=alpha[...,1]/strength
    vacuity=2/strength
    predictive_entropy=-(p*p.clamp_min(1e-8).log()+(1-p)*(1-p).clamp_min(1e-8).log())
    expected_entropy=torch.digamma(strength+1)-(alpha/strength[...,None]*torch.digamma(alpha+1)).sum(-1)
    mutual_information=(predictive_entropy-expected_entropy).clamp_min(0)
    variance=alpha[...,0]*alpha[...,1]/(strength.square()*(strength+1))
    return {'alpha':alpha,'probability':p,'vacuity':vacuity,'epistemic_mi_proxy':mutual_information,'beta_probability_variance':variance}


def wrong_evidence_kl(alpha,y):
    """KL(Dir(tilde alpha) || Dir(1,1)); correct-class evidence is removed."""
    target=F.one_hot(y.clamp(0,1).long(),2).float()
    adjusted=target+(1-target)*alpha
    total=adjusted.sum(-1,keepdim=True)
    return (torch.lgamma(total).squeeze(-1)-torch.lgamma(adjusted).sum(-1)
            +((adjusted-1)*(torch.digamma(adjusted)-torch.digamma(total))).sum(-1))


def orthogonal_private(private,shared):
    # Linear orthogonality is enforced explicitly; this alone does not prove
    # causal or semantically identifiable disentanglement.
    unit=F.normalize(shared,dim=-1,eps=1e-6)
    return private-(private*unit).sum(-1,keepdim=True)*unit


class EvidentialHead(nn.Module):
    def __init__(self,width=512,k=14):
        super().__init__();self.k=k;self.layer=nn.Linear(width,k*2)
    def forward(self,x):return evidence(self.layer(x).reshape(len(x),self.k,2))


class CAMLNet(nn.Module):
    def __init__(self,di=1024,dt=768,k=14,mode='full',max_text=128):
        super().__init__();self.mode=mode;self.k=k;self.max_text=max_text
        self.image_embedding=nn.Sequential(nn.Linear(di,512),nn.GELU(),nn.LayerNorm(512))
        self.text_embedding=nn.Sequential(nn.Linear(dt,512),nn.GELU(),nn.LayerNorm(512))
        self.image_shared=nn.Sequential(nn.Linear(512,512),nn.GELU(),nn.LayerNorm(512))
        self.text_shared=nn.Sequential(nn.Linear(512,512),nn.GELU(),nn.LayerNorm(512))
        self.image_private=nn.Linear(512,512);self.text_private=nn.Linear(512,512)
        self.image_head=EvidentialHead(512,k);self.text_head=EvidentialHead(512,k)
        # Earlier token-level cross-attention requirement is retained through a
        # 64-dimensional attention bottleneck, then returned to width 512.
        self.itoken=nn.Linear(di,64);self.ttoken=nn.Linear(dt,64)
        self.ipos=nn.Parameter(torch.randn(1,32,64)*.02);self.tpos=nn.Parameter(torch.randn(1,max_text,64)*.02)
        self.i_to_t=nn.MultiheadAttention(64,4,dropout=.1,batch_first=True)
        self.t_to_i=nn.MultiheadAttention(64,4,dropout=.1,batch_first=True)
        self.context=nn.Sequential(nn.Linear(128,512),nn.GELU())
        self.gate=nn.Sequential(nn.Linear(512*4+3+2*k+2,128),nn.GELU(),nn.Linear(128,k*2))
        self.fused_weights=nn.Parameter(torch.randn(k,512,2)*.02);self.fused_bias=nn.Parameter(torch.zeros(k,2))
        self.concat_head=nn.Sequential(nn.Linear(1024,256),nn.GELU(),nn.Linear(256,k))

    def forward(self,image,text,imask,tmask,attention=False):
        ai=imask.any(1);at=tmask.any(1);available=torch.stack([ai,at],-1)
        vi=self.image_embedding(mean_tokens(image,imask))*ai[:,None]
        vt=self.text_embedding(mean_tokens(text,tmask))*at[:,None]
        si=self.image_shared(vi)*ai[:,None];st=self.text_shared(vt)*at[:,None]
        pi=orthogonal_private(self.image_private(vi),si)*ai[:,None]
        pt=orthogonal_private(self.text_private(vt),st)*at[:,None]
        if self.mode=='no_private':pi=pi*0;pt=pt*0
        cosine=F.cosine_similarity(si,st,dim=-1,eps=1e-6)
        discrepancy=((si-st).square().mean(-1)+1e-12).sqrt()
        conflict=(.5*(1-cosine)/2+.5*(discrepancy/2).clamp(0,1)).clamp(0,1)
        pair=ai&at
        # Missingness is reported separately, not confused with a mismatch score.
        conflict=conflict*pair;cosine=cosine*pair;discrepancy=discrepancy*pair
        ie=self.image_head(si);te=self.text_head(st)
        result={'image':ie,'text':te,'image_embedding':vi,'text_embedding':vt,
                'shared_image':si,'shared_text':st,'private_image':pi,'private_text':pt,
                'conflict':conflict,'cosine':cosine,'discrepancy':discrepancy,'pair':pair,'available':available}
        if self.mode in {'image','text'}:
            chosen=ie if self.mode=='image' else te
            # Baseline uses its own evidential probability; no fusion/gate.
            return {**result,**chosen,'weights':None,'attention':None}
        if self.mode=='concat':
            z=self.concat_head(torch.cat([vi,vt],-1));p=z.sigmoid()
            return {**result,'probability':p,'logits':z,'alpha':None,'vacuity':None,'epistemic_mi_proxy':None,
                    'beta_probability_variance':None,'weights':None,'attention':None}
        hi=self.itoken(image)*imask[...,None];ht=self.ttoken(text)*tmask[...,None]
        mi=imask.clone();mt=tmask.clone();mi[~ai,0]=True;mt[~at,0]=True
        cross=torch.zeros_like(si);weights_attention=None
        if self.mode!='no_cross_attention':
            ci,_=self.i_to_t(hi+self.ipos[:,:hi.shape[1]],ht+self.tpos[:,:ht.shape[1]],ht,key_padding_mask=~mt,need_weights=False)
            ct,wa=self.t_to_i(ht+self.tpos[:,:ht.shape[1]],hi+self.ipos[:,:hi.shape[1]],hi,key_padding_mask=~mi,need_weights=attention)
            cross=self.context(torch.cat([mean_tokens(hi+ci,imask),mean_tokens(ht+ct,tmask)],-1))*pair[:,None]
            weights_attention=wa
        gate_input=torch.cat([si,st,pi,pt,cosine[:,None],discrepancy[:,None],conflict[:,None],
                              ie['vacuity'],te['vacuity'],available.float()],-1)
        scores=self.gate(gate_input).reshape(-1,self.k,2)
        if self.mode=='no_conflict_gate':
            weights=available[:,None,:].float().expand(-1,self.k,-1)
            weights=weights/weights.sum(-1,keepdim=True).clamp_min(1)
            c=torch.zeros_like(conflict)
        else:
            # Conflict directly enters the gate and increases preference for a
            # lower-vacuity expert. This cannot determine clinical truth.
            unc=torch.stack([ie['vacuity'],te['vacuity']],-1)
            scores=scores-2*conflict[:,None,None]*unc
            weights=scores.masked_fill(~available[:,None,:],-1e4).softmax(-1)*available[:,None,:]
            weights=weights/weights.sum(-1,keepdim=True).clamp_min(1)
            c=conflict
        common=weights[:,:,0,None]*si[:,None]+weights[:,:,1,None]*st[:,None]
        private=weights[:,:,0,None]*pi[:,None]+weights[:,:,1,None]*pt[:,None]
        # High conflict suppresses joint/cross context; private evidence is kept.
        fused=common+(1-c[:,None,None])*cross[:,None]+(.25+.75*c[:,None,None])*private
        raw=torch.einsum('bkd,kdc->bkc',fused,self.fused_weights)+self.fused_bias
        return {**result,**evidence(raw),'weights':weights,'attention':weights_attention}


def masked_mean_loss(value,mask):return (value*mask).sum()/mask.sum().clamp_min(1)


def total_loss(output,y,mode,epoch,lambda_mse=.1,lambda_kl=.01):
    mask=y>=0;t=y.clamp(0,1)
    p=output['probability'].clamp(1e-7,1-1e-7)
    bce=masked_mean_loss(F.binary_cross_entropy(p,t,reduction='none'),mask)
    # Classification BCE also supervises the two shared representations, which
    # discourages an MSE-minimizing constant shared vector.
    if mode not in {'image','text','concat'}:
        auxiliary=[]
        for branch in ('image','text'):
            q=output[branch]['probability'].clamp(1e-7,1-1e-7)
            present=output['available'][:,0 if branch=='image' else 1]
            auxiliary.append(masked_mean_loss(F.binary_cross_entropy(q,t,reduction='none'),mask&present[:,None]))
        bce=(bce+.2*sum(auxiliary))/1.4
    pair=output['pair']
    mse=masked_mean_loss((output['shared_image']-output['shared_text']).square().mean(-1),pair)
    if mode in {'image','text','concat','no_mse'}:mse=mse*0
    kl=bce*0
    if output['alpha'] is not None and mode!='no_kl':
        kl=masked_mean_loss(wrong_evidence_kl(output['alpha'],y),mask)
        if mode not in {'image','text'}:
            aux=[masked_mean_loss(wrong_evidence_kl(output[x]['alpha'],y),mask&output['available'][:,j,None]) for j,x in enumerate(('image','text'))]
            kl=(kl+.2*sum(aux))/1.4
    anneal=min(1.,epoch/5.)
    total=bce+lambda_mse*mse+lambda_kl*anneal*kl
    return total,{'bce':float(bce.detach()),'shared_mse':float(mse.detach()),'evidential_kl':float(kl.detach()),'kl_anneal':anneal}
