"""Frozen, exportable encoders. Real spatial and lexical tokens are preserved."""
from __future__ import annotations
import json
import logging
import hashlib
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image, ImageOps, ImageFilter

TEXT_MODEL = "dmis-lab/biobert-base-cased-v1.2"


def image_tensor(path, blur=False):
    from torchvision.transforms.functional import to_tensor, normalize
    with Image.open(path) as im:
        im = ImageOps.pad(im.convert("RGB"), (224, 224), Image.Resampling.BILINEAR,
                          color=(124, 116, 104))
        if blur:
            im = im.filter(ImageFilter.GaussianBlur(radius=6.0))
    return normalize(to_tensor(im), [.485, .456, .406], [.229, .224, .225])


class Encoders:
    def __init__(self, folder, device="cpu", download=False, max_length=128):
        from torchvision.models import densenet121, DenseNet121_Weights
        from transformers import AutoModel, AutoTokenizer
        self.folder, self.device = Path(folder), torch.device(device)
        self.max_length = max_length
        self.image = densenet121(weights=DenseNet121_Weights.DEFAULT if download else None).features
        text_path = TEXT_MODEL if download else str(self.folder / "text")
        self.tokenizer = AutoTokenizer.from_pretrained(text_path, local_files_only=not download,
                                                       trust_remote_code=False)
        self.text = AutoModel.from_pretrained(text_path, local_files_only=not download,
                                              trust_remote_code=False)
        if not download:
            self.image.load_state_dict(torch.load(self.folder / "image.pt", map_location="cpu", weights_only=True))
        self.image.to(self.device).eval().requires_grad_(False)
        self.text.to(self.device).eval().requires_grad_(False)
        if download:
            self.folder.mkdir(parents=True, exist_ok=True)
            torch.save({k:v.cpu() for k,v in self.image.state_dict().items()}, self.folder / "image.pt")
            self.text.save_pretrained(self.folder / "text", safe_serialization=True)
            self.tokenizer.save_pretrained(self.folder / "text")
            (self.folder / "encoder_config.json").write_text(json.dumps({
                "image":"torchvision/DenseNet121_IMAGENET1K_V1", "text":TEXT_MODEL,
                "image_size":224, "spatial_grid":4, "max_views":2, "max_length":max_length,
                "frozen":True, "cache_dtype":"float16", "image_dim":1024,"text_dim":768}, indent=2))

    @torch.inference_mode()
    def images(self, paths, blur=False):
        # 4x4 spatial tokens per view, two views maximum; neither pooled vector is
        # relabelled as token-level attention. Positional/view embeddings live in the head.
        with ThreadPoolExecutor(max_workers=2) as pool:
            tensors=list(pool.map(lambda p:image_tensor(p,blur),paths))
        x=torch.stack(tensors).to(self.device)
        h=F.adaptive_avg_pool2d(F.relu(self.image(x)),(4,4)).flatten(2).transpose(1,2)
        return h.cpu().numpy().astype(np.float16)

    @torch.inference_mode()
    def reports(self, reports):
        tokens=self.tokenizer(reports,padding="max_length",truncation=True,
                               max_length=self.max_length,return_tensors="pt")
        tokens={k:v.to(self.device) for k,v in tokens.items()}
        h=self.text(**tokens).last_hidden_state
        return h.cpu().numpy().astype(np.float16),tokens["attention_mask"].cpu().numpy().astype(bool)


def choose_views(studies, data_dir):
    """Prefer one frontal and one lateral; retain deterministic fallback order."""
    import csv
    views={}
    files=list(Path(data_dir).rglob("indiana_projections.csv"))
    if len(files)==1:
        with files[0].open(encoding="utf-8-sig",newline="") as f:
            views={r["filename"]:r.get("projection","").casefold() for r in csv.DictReader(f)}
    chosen=[]
    for s in studies:
        front=[p for p in s.images if views.get(Path(p).name)=="frontal"]
        lateral=[p for p in s.images if views.get(Path(p).name)=="lateral"]
        order=(front[:1]+lateral[:1])
        order += [p for p in sorted(s.images) if p not in order]
        chosen.append(order[:2])
    return chosen


def extract(studies, chosen, folder, encoder_folder, signature, device="cpu", batch_size=8,
            max_length=128):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    lock=folder/"extraction.lock"
    try:
        handle=lock.open("x")
    except FileExistsError as exc:
        raise RuntimeError("Another extraction owns this cache. Wait for it to finish. Remove extraction.lock only after confirming that no extraction is running.") from exc
    handle.write("Extraction in progress\n");handle.close()
    try:
        return _extract(studies,chosen,folder,encoder_folder,signature,device,batch_size,max_length)
    finally:
        lock.unlink(missing_ok=True)


def _extract(studies, chosen, folder, encoder_folder, signature, device="cpu", batch_size=8,
             max_length=128):
    """Disk-backed immutable feature cache; completion marker prevents partial reuse."""
    folder=Path(folder); folder.mkdir(parents=True,exist_ok=True)
    marker=folder/"complete.json"
    if marker.exists():
        meta=json.loads(marker.read_text())
        if meta["signature"]!=signature or meta["max_length"]!=max_length:
            raise ValueError("Feature cache fingerprint differs. Use a new --cache directory.")
        logging.info("Reusing complete token cache: %s",folder)
        return load_cache(folder)
    from .cache_resume import TokenCache
    n=len(studies)
    pending=[]
    for i,paths in enumerate(chosen):
        for view,p in enumerate(paths): pending.append((i,view,p))
    weights=Path(encoder_folder)
    fingerprint={'signature':signature,'encoder_batch':batch_size,'device':str(device),
        'torch':str(torch.__version__),
        'inputs_sha256':hashlib.sha256(json.dumps(pending).encode()).hexdigest(),
        'encoding_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'cache_source_sha256':hashlib.sha256(Path(__file__).with_name('cache_resume.py').read_bytes()).hexdigest(),
        'encoder_files':{str(p.relative_to(weights)):hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in sorted(weights.rglob('*')) if p.is_file()}}
    store=TokenCache(folder,fingerprint,[(i,v) for i,v,_ in pending],n,max_length)
    image,text,imask,tmask=[store.arrays[k] for k in ['image','text','imask','tmask']]
    logging.info('Verified cache resume: %d/%d image views, %d/%d reports',store.image_done,len(pending),store.text_done,n)
    enc=Encoders(encoder_folder,device,max_length=max_length)
    for off in range(store.image_done,len(pending),batch_size):
        batch=pending[off:off+batch_size]
        h=enc.images([p for _,_,p in batch])
        if h.shape!=(len(batch),16,1024) or not np.isfinite(h).all():
            raise ValueError('Invalid image token batch')
        for j,(i,view,_) in enumerate(batch):
            image[i,view*16:(view+1)*16]=h[j]; imask[i,view*16:(view+1)*16]=True
        end=off+len(batch)
        if end-store.image_done>=128 or end==len(pending):
            store.commit('image',end)
            logging.info("Spatial image encoding: %d/%d views",end,len(pending))
    for off in range(store.text_done,n,batch_size):
        h,m=enc.reports([s.report for s in studies[off:off+batch_size]])
        if h.shape!=(len(m),max_length,768) or m.shape!=(len(h),max_length) or not np.isfinite(h).all():
            raise ValueError('Invalid report token batch')
        for j,s in enumerate(studies[off:off+batch_size]):
            if s.report: text[off+j]=h[j]; tmask[off+j]=m[j]
        end=min(off+batch_size,n)
        if end-store.text_done>=128 or end==n:
            store.commit('text',end)
            logging.info("Report token encoding: %d/%d studies",end,n)
    store.finish()
    logging.info('CAML_CACHE_CHECKPOINT complete token cache')
    return load_cache(folder)


def load_cache(folder):
    if (Path(folder)/'progress.json').exists():
        from .cache_resume import verify_finished
        return verify_finished(folder)
    return {k:np.load(Path(folder)/f"{k}.npy",mmap_mode="r") for k in ("image","text","imask","tmask")}


def pooled(cache, indices=None):
    # Chunked pooling keeps RAM bounded and includes valid tokens only.
    if indices is None: indices=np.arange(len(cache["image"]))
    result=[]
    for name,maskname in (("image","imask"),("text","tmask")):
        vectors=[]
        for off in range(0,len(indices),128):
            ix=indices[off:off+128]
            h=np.asarray(cache[name][ix],np.float32); m=np.asarray(cache[maskname][ix],np.float32)
            vectors.append((h*m[...,None]).sum(1)/m.sum(1,keepdims=True).clip(1))
        result.append(np.concatenate(vectors))
    return result
