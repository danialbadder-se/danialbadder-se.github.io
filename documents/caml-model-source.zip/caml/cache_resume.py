"""Verified, incremental token-cache checkpoints; independent of Modal/PyTorch."""
from __future__ import annotations
import hashlib
import json
import logging
from pathlib import Path
import numpy as np

SCHEMA = 'CAML_TOKEN_CACHE_V2'


def _write_json(path, data):
    path = Path(path)
    temporary = path.with_name(path.name + '.writing')
    with temporary.open('w', encoding='utf-8') as stream:
        json.dump(data, stream, sort_keys=True)
        stream.flush()
    temporary.replace(path)


def _digest_block(arrays, pending, kind, start, end):
    digest = hashlib.sha256()
    if kind == 'image':
        for study, view in pending[start:end]:
            first = int(view) * arrays['imask'].shape[1] // 2
            stop = first + arrays['imask'].shape[1] // 2
            digest.update(np.asarray(arrays['image'][study, first:stop]).tobytes())
            digest.update(np.asarray(arrays['imask'][study, first:stop]).tobytes())
    else:
        digest.update(np.asarray(arrays['text'][start:end]).tobytes())
        digest.update(np.asarray(arrays['tmask'][start:end]).tobytes())
    return digest.hexdigest()


class TokenCache:
    def __init__(self, folder, fingerprint, pending, studies, max_length,
                 image_dim=1024, text_dim=768, spatial_tokens=16):
        self.folder = Path(folder)
        self.folder.mkdir(parents=True, exist_ok=True)
        self.pending = np.asarray(pending, dtype=np.int64).reshape(-1, 2)
        self.spec = {'image': [studies, 2*spatial_tokens, image_dim],
                     'text': [studies, max_length, text_dim],
                     'imask': [studies, 2*spatial_tokens], 'tmask': [studies, max_length]}
        if studies < 1 or max_length < 1 or spatial_tokens < 1:
            raise ValueError('Invalid cache dimensions')
        if len(self.pending) and (self.pending[:, 0].min() < 0 or self.pending[:, 0].max() >= studies
                                  or not np.isin(self.pending[:, 1], [0, 1]).all()):
            raise ValueError('Invalid view/study mapping')
        if len({tuple(x) for x in self.pending}) != len(self.pending):
            raise ValueError('Duplicate image view in cache mapping')
        self.fingerprint = {**fingerprint, 'shapes': self.spec,
                            'pending_sha256': hashlib.sha256(self.pending.tobytes()).hexdigest()}
        progress = self.folder / 'progress.json'
        if progress.exists():
            self.state = json.loads(progress.read_text())
            if self.state.get('schema') != SCHEMA or self.state.get('fingerprint') != self.fingerprint:
                raise ValueError('Token cache provenance differs; use a fresh run/cache')
            self.arrays = self._open('r+')
            stored_pending = np.load(self.folder/'pending.npy', allow_pickle=False)
            if not np.array_equal(stored_pending, self.pending):
                raise ValueError('Token cache image mapping differs')
            self.verify()
            # Ignore writes that never acquired a committed progress record.
            for study, view in self.pending[self.image_done:]:
                a = int(view)*spatial_tokens
                self.arrays['image'][study, a:a+spatial_tokens] = 0
                self.arrays['imask'][study, a:a+spatial_tokens] = False
            self.arrays['text'][self.text_done:] = 0
            self.arrays['tmask'][self.text_done:] = False
        else:
            self.state = {'schema': SCHEMA, 'fingerprint': self.fingerprint,
                          'image_done': 0, 'text_done': 0, 'image_blocks': [], 'text_blocks': []}
            self.arrays = self._open('w+')
            for value in self.arrays.values():
                value[:] = 0
            np.save(self.folder/'pending.npy', self.pending, allow_pickle=False)
            self._save()

    def _open(self, mode):
        arrays = {}
        for name, shape in self.spec.items():
            dtype = np.dtype('bool' if name.endswith('mask') else 'float16')
            path = self.folder/(name+'.npy')
            if mode == 'w+':
                value = np.lib.format.open_memmap(path, mode='w+', dtype=dtype, shape=tuple(shape))
            else:
                value = np.load(path, mmap_mode=mode, allow_pickle=False)
                if list(value.shape) != shape or value.dtype != dtype:
                    raise ValueError('Token-cache array shape/dtype differs: '+name)
            arrays[name] = value
        return arrays

    @property
    def image_done(self):
        return self.state['image_done']

    @property
    def text_done(self):
        return self.state['text_done']

    def _save(self):
        for value in self.arrays.values():
            value.flush()
        _write_json(self.folder/'progress.json', self.state)
        # The Modal parent commits its Volume only after the arrays and marker
        # have been flushed. Non-Modal callers simply receive a progress log.
        logging.info('CAML_CACHE_CHECKPOINT images=%d/%d reports=%d/%d',
                     self.image_done, len(self.pending), self.text_done, self.spec['text'][0])

    def commit(self, kind, end):
        key = 'image' if kind == 'image' else 'text' if kind == 'text' else None
        if key is None:
            raise ValueError('Unknown checkpoint kind')
        start = self.state[key+'_done']
        total = len(self.pending) if key == 'image' else self.spec['text'][0]
        if not start < end <= total:
            raise ValueError('Invalid cache checkpoint boundary')
        if key == 'text' and self.image_done != len(self.pending):
            raise ValueError('Image extraction must finish before report extraction')
        self.state[key+'_blocks'].append({'start': start, 'end': end,
                                         'sha256': _digest_block(self.arrays, self.pending, key, start, end)})
        self.state[key+'_done'] = end
        self._save()

    def verify(self):
        for key, total in [('image', len(self.pending)), ('text', self.spec['text'][0])]:
            previous = 0
            for block in self.state[key+'_blocks']:
                if block['start'] != previous or not previous < block['end'] <= total:
                    raise ValueError('Invalid checkpoint sequence')
                if _digest_block(self.arrays, self.pending, key, previous, block['end']) != block['sha256']:
                    raise ValueError('Committed token-cache checksum differs')
                previous = block['end']
            if previous != self.state[key+'_done']:
                raise ValueError('Cache progress counter differs')
        if self.text_done and self.image_done != len(self.pending):
            raise ValueError('Inconsistent image/report progress')

    def finish(self):
        if self.image_done != len(self.pending) or self.text_done != self.spec['text'][0]:
            raise ValueError('Cannot publish an incomplete token cache')
        self.verify()
        _write_json(self.folder/'complete.json', {'schema': SCHEMA,
                    'signature': self.fingerprint['signature'],
                    'max_length': self.spec['text'][1], 'studies': self.spec['text'][0],
                    'text_encoder': 'dmis-lab/biobert-base-cased-v1.2',
                    'progress_sha256': hashlib.sha256((self.folder/'progress.json').read_bytes()).hexdigest()})


def verify_finished(folder):
    folder = Path(folder)
    state = json.loads((folder/'progress.json').read_text())
    marker = json.loads((folder/'complete.json').read_text())
    if state.get('schema') != SCHEMA or marker.get('schema') != SCHEMA:
        raise ValueError('Unknown cache checkpoint schema')
    if hashlib.sha256((folder/'progress.json').read_bytes()).hexdigest() != marker.get('progress_sha256'):
        raise ValueError('Completed cache progress checksum differs')
    pending = np.load(folder/'pending.npy', allow_pickle=False)
    if hashlib.sha256(pending.tobytes()).hexdigest() != state['fingerprint']['pending_sha256']:
        raise ValueError('Cache view mapping checksum differs')
    obj = TokenCache.__new__(TokenCache)
    obj.folder, obj.state, obj.pending = folder, state, pending
    obj.spec = state['fingerprint']['shapes']
    obj.arrays = obj._open('r')
    obj.verify()
    if obj.image_done != len(pending) or obj.text_done != obj.spec['text'][0]:
        raise ValueError('Completed cache has incomplete blocks')
    return obj.arrays
