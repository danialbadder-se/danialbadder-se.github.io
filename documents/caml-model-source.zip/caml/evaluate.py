"""Missingness, controlled discrepancy and quantitative uncertainty checks."""
from __future__ import annotations
import json,logging
from pathlib import Path
import numpy as np
from scipy.special import expit,logit
from sklearn.metrics import roc_auc_score,average_precision_score
from .iu_io import dump_json,write_csv
from .engine import infer,restore,triage
from .statistics import metric_values,bootstrap_paired


def report_missingness(args,cache,y,split,studies,active):
    root=Path(args.output);ix=np.flatnonzero(split=='test');groups=np.array([studies[i].group for i in ix])
    unique=np.unique(groups);rows=[];saved={}
    for missing_seed in [901,902,903]:
        rng=np.random.default_rng(missing_seed);ordered=unique.copy();rng.shuffle(ordered)
        for rate in [0,.2,.4,.6,.8]:
            missing=np.isin(groups,ordered[:int(round(rate*len(ordered)))])
            parts=[];triages=[];us=[];cs=[]
            for seed in args.seeds:
                folder=root/f'seed_{seed}';model,norm,cp=restore(folder/'full.pt',args.device)
                cal=json.loads((folder/'full_metrics.json').read_text())['calibration']
                raw=infer(model,cache,ix,norm,args.device,args.batch_size,missing)
                p=expit(logit(raw['probability'].clip(1e-7,1-1e-7))/cal['temperature']);parts.append(p)
                triages.append(triage(p,raw['vacuity'],raw['conflict'],raw['available'],cal['triage'],active))
                us.append(raw['vacuity']);cs.append(raw['conflict'])
            probability=np.mean(parts,axis=0);m=metric_values(y[ix],probability)
            key=f'missing_{int(rate*100)}_draw_{missing_seed}'
            saved[key]={'metrics':m,'requested_rate':rate,'actual_study_rate':float(missing.mean()),
                        'missing_groups':int(np.unique(groups[missing]).size),
                        'triage_counts_first_seed':{k:triages[0].count(k) for k in sorted(set(triages[0]))},
                        'mean_vacuity':float(np.mean(us,axis=0)[:,active].mean())}
            rows.append({'requested_report_missingness':rate,'actual_report_missingness':float(missing.mean()),
                         'missingness_seed':missing_seed,**{k:v for k,v in m.items() if k!='calibration_bins'},
                         'mean_vacuity':saved[key]['mean_vacuity']})
            np.savez_compressed(root/f'{key}.npz',probability=probability,indices=ix,missing=missing)
            logging.info('Report missingness %.0f%% draw %d Brier %.5f',rate*100,missing_seed,m['brier'])
    dump_json(root/'missingness_results.json',{'policy':'MCAR by entire study/patient group; nested masks; clean-fit weights, calibration and triage settings remain locked',
              'rates':[0,.2,.4,.6,.8],'mask_seeds':[901,902,903],'model':'full ensemble','results':saved})
    write_csv(root/'missingness_sweep.csv',rows)
    return rows


def controlled_conflict(args,cache,y,split,studies):
    """Cross-study swaps with at least one known differing finding, not clinical truth."""
    from .engine import batch
    import torch
    root=Path(args.output);ix=np.flatnonzero(split=='test');rng=np.random.default_rng(432)
    partners=[];eligible=[]
    for i in ix:
        candidates=[j for j in ix if studies[i].group!=studies[j].group and np.any((y[i]>=0)&(y[j]>=0)&(y[i]!=y[j]))]
        if candidates:eligible.append(int(i));partners.append(int(rng.choice(candidates)))
    eligible=np.asarray(eligible);partners=np.asarray(partners);matched=[];swapped=[]
    for seed in args.seeds:
        model,norm,cp=restore(root/f'seed_{seed}/full.pt',args.device);a=[];b=[]
        with torch.inference_mode():
            for off in range(0,len(eligible),args.batch_size):
                src=eligible[off:off+args.batch_size];dst=partners[off:off+args.batch_size]
                original=batch(cache,src,norm,args.device);other=batch(cache,dst,norm,args.device)
                a.append(model(*original)['conflict'].cpu().numpy())
                b.append(model(original[0],other[1],original[2],other[3])['conflict'].cpu().numpy())
        matched.append(np.concatenate(a));swapped.append(np.concatenate(b))
    good=np.mean(matched,axis=0);bad=np.mean(swapped,axis=0)
    truth=np.r_[np.zeros(len(good)),np.ones(len(bad))];score=np.r_[good,bad]
    # This is an alignment/discrepancy probe; swaps can remain clinically compatible.
    result={'status':'controlled_differing_weak_label_report_swaps_not_clinical_contradictions',
            'studies':len(eligible),'auroc':float(roc_auc_score(truth,score)),
            'average_precision':float(average_precision_score(truth,score)),
            'mean_matched_conflict':float(good.mean()),'mean_swapped_conflict':float(bad.mean()),
            'qualification':'Different report-derived findings do not prove a true image/report conflict. Source correctness and medical hallucination prevention are not established.'}
    dump_json(root/'controlled_conflict.json',result)
    np.savez_compressed(root/'controlled_conflict.npz',source_indices=eligible,report_indices=partners,matched=good,swapped=bad)
    return result


def plots(root,comparison,missing_rows):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    root=Path(root);names=[r['model'] for r in comparison]
    fig,axes=plt.subplots(1,3,figsize=(13,5))
    for ax,key,title in zip(axes,['macro_auroc','micro_f1','brier'],['Macro AUROC','Micro F1 (threshold 0.5)','Brier score (lower better)']):
        ax.barh(names[::-1],[r[key] for r in comparison][::-1],color=['#174d68' if n=='full' else '#7eafbd' for n in names[::-1]])
        ax.set_title(title);ax.grid(axis='x',alpha=.2)
    fig.suptitle('CAML-Net | Open-I weak-label prototype | Conditional research results')
    fig.tight_layout();fig.savefig(root/'ablation_comparison.png',dpi=150);plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(11,3.5))
    for ax,key,title in zip(axes,['macro_auroc','micro_f1','brier'],['AUROC','Micro F1','Brier']):
        rates=sorted(set(r['requested_report_missingness'] for r in missing_rows))
        values=[[r[key] for r in missing_rows if r['requested_report_missingness']==rate] for rate in rates]
        ax.errorbar(np.array(rates)*100,[np.mean(v) for v in values],yerr=[np.std(v,ddof=1) for v in values],marker='o',color='#174d68',capsize=3)
        ax.set(xlabel='Reports missing (%)',ylabel=title);ax.grid(alpha=.2)
    fig.suptitle('Full model | 3 nested missingness draws; SD is mask variability')
    fig.tight_layout();fig.savefig(root/'report_missingness_0_to_80.png',dpi=150);plt.close(fig)
