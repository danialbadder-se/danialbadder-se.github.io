"""Proper scores, validation-only thresholds and paired group-level inference."""
from __future__ import annotations
import numpy as np
from scipy.special import expit,logit
from scipy.optimize import minimize_scalar
from sklearn.metrics import roc_auc_score,average_precision_score


def fit_temperature(logits,y):
    mask=y>=0
    if not mask.any(): raise ValueError("No known calibration labels")
    x=np.asarray(logits,dtype=np.float64)[mask]; t=np.asarray(y)[mask]
    def objective(log_t):
        z=x/np.exp(log_t)
        return np.mean(np.logaddexp(0,z)-t*z)
    result=minimize_scalar(objective,bounds=(np.log(.2),np.log(10)),method="bounded")
    return float(np.exp(result.x))


def thresholds_from_validation(p,y):
    # A fixed, declared grid; maximize per-finding validation F1, break ties
    # towards .5. No calibration or test outcomes are accepted here.
    grid=np.unique(np.concatenate([np.linspace(.05,.95,19),[.5]])); result=[]
    for j in range(y.shape[1]):
        m=y[:,j]>=0; target=y[m,j]
        if (target==1).sum()<3 or (target==0).sum()<3:
            result.append(.5); continue
        scores=[]
        for t in grid:
            pred=p[m,j]>=t
            tp=np.sum(pred&(target==1)); fp=np.sum(pred&(target==0)); fn=np.sum(~pred&(target==1))
            scores.append(2*tp/max(1,2*tp+fp+fn))
        best=max(scores)
        choices=grid[np.isclose(scores,best)]
        result.append(float(choices[np.argmin(np.abs(choices-.5))]))
    return np.asarray(result)


def counts(y,p,threshold=.5):
    mask=y>=0; pred=p>=np.asarray(threshold); positive=y==1
    return np.stack([(pred&positive&mask).sum(0),(pred&~positive&mask).sum(0),
                     (~pred&positive&mask).sum(0),(~pred&~positive&mask).sum(0)],-1)


def metric_values(y,p,threshold=.5):
    mask=y>=0; p=np.clip(np.asarray(p,dtype=np.float64),1e-7,1-1e-7)
    c=counts(y,p,threshold); tp,fp,fn,tn=c.T; total=mask.sum()
    if total==0: raise ValueError("No eligible known labels")
    sq=(p-y.clip(0,1))**2
    nll=-(y.clip(0,1)*np.log(p)+(1-y.clip(0,1))*np.log1p(-p))
    f1=2*tp/np.maximum(1,2*tp+fp+fn)
    aucs=[]; aps=[]; balanced=[]
    for j in range(y.shape[1]):
        m=mask[:,j]; t=y[m,j]; q=p[m,j]
        if len(np.unique(t))==2:
            aucs.append(roc_auc_score(t,q)); aps.append(average_precision_score(t,q))
            balanced.append(.5*np.mean((q[t==1]-1)**2)+.5*np.mean(q[t==0]**2))
    bins=[]; ece=0.
    for i in range(10):
        m=mask&(p>=i/10)&(p<(i+1)/10 if i<9 else p<=1)
        n=int(m.sum())
        mean=float(p[m].mean()) if n else None; freq=float(y[m].mean()) if n else None
        if n: ece+=n/total*abs(mean-freq)
        bins.append({"lower":i/10,"upper":(i+1)/10,"n":n,"mean_probability":mean,"positive_frequency":freq})
    return {"studies":len(y),"known_labels":int(total),"positive_labels":int((y==1).sum()),
            "macro_auroc":float(np.mean(aucs)) if aucs else None,"auroc_defined_classes":len(aucs),
            "macro_average_precision":float(np.mean(aps)) if aps else None,
            "micro_f1":float(2*tp.sum()/max(1,2*tp.sum()+fp.sum()+fn.sum())),
            "macro_f1":float(f1[mask.any(0)].mean()),"micro_precision":float(tp.sum()/max(1,tp.sum()+fp.sum())),
            "micro_recall":float(tp.sum()/max(1,tp.sum()+fn.sum())),
            "micro_label_accuracy":float((tp.sum()+tn.sum())/total),
            "brier":float(sq[mask].mean()),"balanced_brier":float(np.mean(balanced)) if balanced else None,
            "nll":float(nll[mask].mean()),"pooled_ece_10_bins":float(ece),"calibration_bins":bins}


def per_class(y,p,labels,threshold=.5):
    c=counts(y,p,threshold); out=[]
    thresholds=np.broadcast_to(threshold,(len(labels),))
    for j,label in enumerate(labels):
        tp,fp,fn,tn=map(int,c[j]); m=y[:,j]>=0; t=y[m,j]; q=p[m,j]
        out.append({"label":label,"positive_support":int((t==1).sum()),"negative_support":int((t==0).sum()),
                    "threshold":float(thresholds[j]),"tp":tp,"fp":fp,"fn":fn,"tn":tn,
                    "f1":float(2*tp/max(1,2*tp+fp+fn)),"recall":float(tp/max(1,tp+fn)),
                    "precision":float(tp/max(1,tp+fp)),
                    "auroc":float(roc_auc_score(t,q)) if len(np.unique(t))==2 else None,
                    "average_precision":float(average_precision_score(t,q)) if (t==1).any() else None})
    return out


def selective_risk(y,p,variance=None):
    q=np.clip(p,1e-7,1-1e-7)
    entropy=-(q*np.log(q)+(1-q)*np.log1p(-q)).mean(1)
    # Fixed score, not tuned using evaluation outcomes.
    score=entropy+(np.asarray(variance).mean(1) if variance is not None else 0)
    order=np.argsort(score,kind="stable"); rows=[]
    for coverage in (.25,.5,.75,1.):
        ix=order[:max(1,int(np.ceil(len(y)*coverage)))]; m=y[ix]>=0
        rows.append({"coverage":coverage,"retained":len(ix),"brier":float(((p[ix]-y[ix].clip(0,1))**2)[m].mean())})
    return rows


def group_contributions(y,p,groups):
    unique=np.unique(groups); values=[]
    for group in unique:
        ix=np.asarray(groups)==group; t=y[ix]; q=np.clip(p[ix],1e-7,1-1e-7); m=t>=0
        c=counts(t,q).sum(0); tp,fp,fn,tn=c
        sq=((q-t.clip(0,1))**2)[m].sum()
        nll=-(t.clip(0,1)*np.log(q)+(1-t.clip(0,1))*np.log1p(-q))[m].sum()
        values.append([sq,m.sum(),nll,tp,fp,fn])
    return np.asarray(values,np.float64)


def summarize_contributions(v):
    return np.stack([v[...,0]/v[...,1].clip(1),v[...,2]/v[...,1].clip(1),
                     2*v[...,3]/(2*v[...,3]+v[...,4]+v[...,5]).clip(1)],-1)


def bootstrap_paired(y,probabilities,groups,replicates=1000,seed=781):
    """Percentile group bootstrap, conditional on saved fitted models.

    Entire groups and all findings move together. Does not include training-set
    sampling uncertainty or establish transportability to another hospital.
    """
    rng=np.random.default_rng(seed); names=list(probabilities)
    contributions={n:group_contributions(y,p,groups) for n,p in probabilities.items()}
    g=len(next(iter(contributions.values()))); draws=rng.integers(0,g,size=(replicates,g))
    distributions={n:summarize_contributions(v[draws].sum(1)) for n,v in contributions.items()}
    result={"replicates":replicates,"groups":g,"seed":seed,"method":"paired_group_percentile_bootstrap_95pct",
            "metric_order":["brier","nll","micro_f1_at_0_5"],"models":{},"full_minus_baseline":{}}
    for name,dist in distributions.items():
        lo,hi=np.quantile(dist,[.025,.975],axis=0)
        point=summarize_contributions(contributions[name].sum(0))
        result["models"][name]={k:{"estimate":float(point[i]),"lower":float(lo[i]),"upper":float(hi[i])}
                                  for i,k in enumerate(result["metric_order"])}
        if name!="full" and "full" in distributions:
            diff=distributions["full"]-dist; low,high=np.quantile(diff,[.025,.975],axis=0)
            point_diff=summarize_contributions(contributions["full"].sum(0))-point
            result["full_minus_baseline"][name]={k:{"estimate":float(point_diff[i]),"lower":float(low[i]),"upper":float(high[i])}
                for i,k in enumerate(result["metric_order"])}
    return result


def holm_adjust(pvalues):
    pvalues=np.asarray(pvalues,float); order=np.argsort(pvalues); adjusted=np.empty_like(pvalues); previous=0.
    for rank,j in enumerate(order):
        previous=max(previous,min(1.,(len(pvalues)-rank)*pvalues[j])); adjusted[j]=previous
    return adjusted


def paired_permutation(y,probabilities,groups,replicates=2000,seed=782):
    """Randomly swap model contributions within whole groups (paired design)."""
    rng=np.random.default_rng(seed); full=group_contributions(y,probabilities["full"],groups)
    rows=[]
    for name,p in probabilities.items():
        if name=="full": continue
        other=group_contributions(y,p,groups)
        point=summarize_contributions(full.sum(0))-summarize_contributions(other.sum(0))
        exceed=np.zeros(3,int)
        for off in range(0,replicates,250):
            take=min(250,replicates-off); swap=rng.integers(0,2,size=(take,len(full),1))
            a=(np.where(swap,full,other)).sum(1); b=(np.where(swap,other,full)).sum(1)
            delta=summarize_contributions(a)-summarize_contributions(b)
            exceed+=(np.abs(delta)>=np.abs(point)-1e-14).sum(0)
        for j,metric in enumerate(("brier","nll","micro_f1_at_0_5")):
            rows.append({"contrast":f"full_minus_{name}","metric":metric,"difference":float(point[j]),
                         "p_two_sided":float((exceed[j]+1)/(replicates+1))})
    # One declared family across every model contrast and these three endpoints.
    adjusted=holm_adjust([r["p_two_sided"] for r in rows])
    for r,padj in zip(rows,adjusted):r["p_holm"]=float(padj)
    return {"replicates":replicates,"seed":seed,"unit":"study/duplicate-image group; patient ID if supplied",
            "family":"all declared full-versus-baseline/ablation contrasts times three endpoints", "tests":rows}


def challenge_statistics(target,learned,rule,groups,bootstrap=1000,permutations=2000,seed=1783):
    """Keep every original/flipped assertion from a study together."""
    rng=np.random.default_rng(seed);unique=np.unique(groups)
    members=[np.flatnonzero(groups==g) for g in unique]
    def score(t,p):return np.array([roc_auc_score(t,p),np.mean((p-t)**2)])
    point_l=score(target,learned);point_r=score(target,rule);draw_l=[];draw_r=[]
    for _ in range(bootstrap):
        ix=np.concatenate([members[j] for j in rng.integers(0,len(members),len(members))])
        draw_l.append(score(target[ix],learned[ix]));draw_r.append(score(target[ix],rule[ix]))
    draw_l=np.asarray(draw_l);draw_r=np.asarray(draw_r)
    out={"unit":"entire study/group; original and flipped rows kept together", "groups":len(unique),
         "bootstrap_replicates":bootstrap,"permutation_replicates":permutations,
         "learned":{},"image_rule":{},"learned_minus_image_rule":{}}
    low_l,high_l=np.quantile(draw_l,[.025,.975],axis=0);low_r,high_r=np.quantile(draw_r,[.025,.975],axis=0)
    low_d,high_d=np.quantile(draw_l-draw_r,[.025,.975],axis=0)
    differences=point_l-point_r;exceed=np.zeros(2,int)
    group_index=np.searchsorted(unique,groups)
    for _ in range(permutations):
        swap=rng.integers(0,2,len(unique))[group_index].astype(bool)
        a=np.where(swap,learned,rule);b=np.where(swap,rule,learned)
        diff=score(target,a)-score(target,b)
        exceed+=np.abs(diff)>=np.abs(differences)-1e-14
    p=(exceed+1)/(permutations+1);adjusted=holm_adjust(p)
    for j,metric in enumerate(("pooled_challenge_auroc","brier")):
        out["learned"][metric]={"estimate":float(point_l[j]),"lower":float(low_l[j]),"upper":float(high_l[j])}
        out["image_rule"][metric]={"estimate":float(point_r[j]),"lower":float(low_r[j]),"upper":float(high_r[j])}
        out["learned_minus_image_rule"][metric]={"estimate":float(differences[j]),"lower":float(low_d[j]),"upper":float(high_d[j]),
                                                "p_two_sided":float(p[j]),"p_holm_two_endpoint_family":float(adjusted[j])}
    return out
