from __future__ import annotations
import json,logging,time,copy
from pathlib import Path
import numpy as np
import torch
from scipy.special import expit,logit
from .model import CAMLNet,total_loss,MODES
from .iu_io import dump_json,write_csv,seed_all
from .encoders import load_cache,pooled
from .statistics import metric_values,per_class,fit_temperature,thresholds_from_validation,bootstrap_paired,paired_permutation


def batch(cache,ix,norm,device,drop=None):
    values=[]
    for name,maskname,key in [('image','imask','i'),('text','tmask','t')]:
        h=np.array(cache[name][ix],np.float32,copy=True);m=np.array(cache[maskname][ix],bool,copy=True)
        h=(h-norm['mean_'+key])/norm['std_'+key];h*=m[...,None]
        if drop is not None and name=='text':h[drop]=0;m[drop]=False
        values.extend([torch.as_tensor(h,device=device),torch.as_tensor(m,device=device)])
    return values[0],values[2],values[1],values[3]


def state_cpu(model):return {k:v.detach().cpu().clone() for k,v in model.state_dict().items()}


def fit(cache,y,split,active,norm,mode,seed,args):
    seed_all(seed);device=torch.device(args.device);folder=Path(args.output)/f'seed_{seed}';folder.mkdir(exist_ok=True)
    model=CAMLNet(cache['image'].shape[-1],cache['text'].shape[-1],14,mode,cache['text'].shape[1]).to(device)
    opt=torch.optim.AdamW(model.parameters(),lr=args.lr,weight_decay=.01)
    train=np.flatnonzero(split=='train');val=np.flatnonzero(split=='val');rng=np.random.default_rng(seed)
    concordant=np.load(Path(args.output)/'pair_concordant.npy')
    best=float('inf');snapshot=None;stale=0;chosen=0;history=[]
    for epoch in range(1,args.epochs+1):
        model.train();order=rng.permutation(train);losses=[];parts=[];start=time.monotonic()
        for off in range(0,len(order),args.batch_size):
            ix=order[off:off+args.batch_size];inputs=list(batch(cache,ix,norm,device))
            if mode not in {'image','text','concat'}:
                # Missing-modality augmentation never changes the weak targets.
                choices=rng.random(len(ix));di=torch.as_tensor(choices<.1,device=device);dt=torch.as_tensor((choices>=.1)&(choices<.4),device=device)
                inputs[0][di]=0;inputs[2][di]=False;inputs[1][dt]=0;inputs[3][dt]=False
            output=model(*inputs);target=torch.as_tensor(y[ix],device=device)
            output['pair']=output['pair'] & torch.as_tensor(concordant[ix]==1,device=device)
            loss,pieces=total_loss(output,target,mode,epoch,args.lambda_mse,args.lambda_kl)
            if not torch.isfinite(loss):raise FloatingPointError('Non-finite CAML loss')
            opt.zero_grad();loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5);opt.step()
            losses.append(float(loss.detach()));parts.append(pieces)
        prediction=infer(model,cache,val,norm,device,args.batch_size)['probability']
        t=y[val];mask=t>=0;p=prediction.clip(1e-7,1-1e-7)
        nll=float((-(t.clip(0,1)*np.log(p)+(1-t.clip(0,1))*np.log1p(-p)))[mask].mean())
        row={'epoch':epoch,'train_loss':float(np.mean(losses)),'val_nll':nll,'seconds':time.monotonic()-start,
             **{k:float(np.mean([d[k] for d in parts])) for k in parts[0]}}
        history.append(row);logging.info('seed %d %s epoch %d/%d loss %.4f val NLL %.4f (%.1fs)',seed,mode,epoch,args.epochs,row['train_loss'],nll,row['seconds'])
        if nll<best-1e-5:best=nll;snapshot=state_cpu(model);chosen=epoch;stale=0
        else:stale+=1
        if stale>=args.patience:break
    model.load_state_dict(snapshot);model.eval()
    selected_path=folder/f'{mode}.pt'
    temporary_path=folder/f'{mode}.pt.partial'
    torch.save({'version':'CAML-1.0.0','mode':mode,'seed':seed,'state_dict':snapshot,
                'dims':[cache['image'].shape[-1],cache['text'].shape[-1],14],
                'max_text':cache['text'].shape[1],'active_labels':torch.from_numpy(active),
                'normalization':{k:torch.from_numpy(v) for k,v in norm.items()},
                'selected_epoch':chosen,'best_val_nll':best,'selection':'clean validation NLL'},temporary_path)
    temporary_path.replace(selected_path)
    write_csv(folder/f'{mode}_history.csv',history)
    return model


@torch.inference_mode()
def infer(model,cache,indices,norm,device,batch_size=32,missing=None):
    model.eval();parts={k:[] for k in ['probability','alpha','vacuity','epistemic_mi_proxy','beta_probability_variance','conflict','cosine','discrepancy','available','weights']}
    for off in range(0,len(indices),batch_size):
        ix=indices[off:off+batch_size];drop=None if missing is None else missing[off:off+batch_size]
        out=model(*batch(cache,ix,norm,device,drop))
        for k in parts:
            if out.get(k) is not None:parts[k].append(out[k].cpu().numpy())
    return {k:np.concatenate(v) if v else None for k,v in parts.items()}


def restore(path,device='cpu'):
    cp=torch.load(path,map_location='cpu',weights_only=True)
    model=CAMLNet(*cp['dims'],mode=cp['mode'],max_text=cp['max_text']).to(device)
    model.load_state_dict(cp['state_dict']);model.eval()
    return model,{k:v.numpy() for k,v in cp['normalization'].items()},cp


def triage_settings(predictions,calibrated,split,active):
    v=split=='val'
    if predictions['vacuity'] is None:return None
    uncertainty=predictions['vacuity'][:,active].max(1)
    # Declared validation-reference quantiles, not clinical risk guarantees.
    return {'conflict_high':float(np.quantile(predictions['conflict'][v],.95)),
            'conflict_low':float(np.quantile(predictions['conflict'][v],.5)),
            'uncertainty_high':float(np.quantile(uncertainty[v],.8)),
            'uncertainty_low':float(np.quantile(uncertainty[v],.5)),
            'minimum_decision_confidence_high':.9,
            'policy':'validation-reference quantiles; any missing modality routes to High Uncertainty / Conflict; not clinically calibrated triage'}


def triage(probability,vacuity,conflict,available,settings,active):
    if settings is None or vacuity is None:return ['Not applicable: non-evidential baseline']*len(probability)
    unc=vacuity[:,active].max(1);confidence=np.maximum(probability[:,active],1-probability[:,active]).min(1)
    result=[]
    for i in range(len(probability)):
        if not available[i].all() or conflict[i]>settings['conflict_high'] or unc[i]>settings['uncertainty_high']:value='High Uncertainty / Conflict'
        elif conflict[i]<=settings['conflict_low'] and unc[i]<=settings['uncertainty_low'] and confidence[i]>=settings['minimum_decision_confidence_high']:value='High Confidence'
        else:value='Moderate Confidence'
        result.append(value)
    return result


def calibrate(raw,y,split,active):
    p=raw['probability'];z=logit(p.clip(1e-7,1-1e-7))
    temperature=fit_temperature(z[split=='cal'],y[split=='cal'])
    calibrated=expit(z/temperature)
    raw_threshold=thresholds_from_validation(p[split=='val'],y[split=='val'])
    threshold=expit(logit(raw_threshold)/temperature)
    return calibrated,{'temperature':temperature,'threshold':threshold.tolist(),
            'triage':triage_settings(raw,calibrated,split,active),
            'evidential_calibration_scope':'BCE+wrong-evidence KL training; held-out temperature calibrates probabilities ONLY. Raw Beta evidence/vacuity are retained and empirically evaluated, not certified epistemic posteriors.'}


def evaluate_mode(raw,p,calibration,y,split,active,labels,folder,mode):
    ix=np.flatnonzero(split=='test');fixed=metric_values(y[ix],p[ix]);secondary=metric_values(y[ix],p[ix],calibration['threshold'])
    decisions=triage(p,raw['vacuity'],raw['conflict'],raw['available'],calibration['triage'],active)
    uncertainty={}
    if raw['vacuity'] is not None:
        u=raw['vacuity'][ix];known=y[ix]>=0;error=(p[ix]>=.5)!=(y[ix]==1)
        from sklearn.metrics import roc_auc_score
        uncertainty={'error_detection_auroc':float(roc_auc_score(error[known],u[known])) if len(np.unique(error[known]))==2 else None,
                     'mean_vacuity':float(u[:,active].mean()),'triage_counts':{k:decisions.count(k) for k in sorted(set(decisions))}}
    result={'fixed_threshold_0_5':fixed,'validation_thresholds':secondary,'calibration':calibration,'uncertainty':uncertainty,
            'test_triage_counts':{k:sum(decisions[i]==k for i in ix) for k in sorted(set(decisions))}}
    dump_json(Path(folder)/f'{mode}_metrics.json',result)
    write_csv(Path(folder)/f'{mode}_per_class.csv',per_class(y[ix],p[ix],labels))
    np.savez_compressed(Path(folder)/f'{mode}_predictions.npz',probability=p,raw_probability=raw['probability'],
        alpha=raw['alpha'] if raw['alpha'] is not None else np.empty(0),
        vacuity=raw['vacuity'] if raw['vacuity'] is not None else np.empty(0),
        epistemic_mi_proxy=raw['epistemic_mi_proxy'] if raw['epistemic_mi_proxy'] is not None else np.empty(0),
        conflict=raw['conflict'],available=raw['available'],test_indices=ix)
    return result


def aggregate(args,studies,y,split,labels):
    root=Path(args.output);ix=np.flatnonzero(split=='test');groups=np.array([studies[i].group for i in ix]);rows=[];probs={}
    for mode in args.modes:
        seedpred=[np.load(root/f'seed_{s}/{mode}_predictions.npz')['probability'] for s in args.seeds]
        p=np.mean(seedpred,axis=0);probs[mode]=p[ix];point=metric_values(y[ix],p[ix]);row={'model':mode,'seeds':len(args.seeds)}
        for metric in ['macro_auroc','macro_average_precision','micro_f1','macro_f1','brier','balanced_brier','nll','pooled_ece_10_bins']:
            values=[json.loads((root/f'seed_{s}/{mode}_metrics.json').read_text())['fixed_threshold_0_5'][metric] for s in args.seeds]
            valid=[v for v in values if v is not None]
            row[metric]=point[metric];row[metric+'_seed_mean']=float(np.mean(valid)) if valid else None
            row[metric+'_seed_sd']=float(np.std(valid,ddof=1)) if len(valid)>1 else None
        rows.append(row)
    write_csv(root/'model_comparison.csv',rows)
    dump_json(root/'bootstrap_95ci.json',bootstrap_paired(y[ix],probs,groups,args.bootstrap))
    dump_json(root/'permutation_holm.json',paired_permutation(y[ix],probs,groups,args.permutations))
    np.savez_compressed(root/'ensemble_predictions.npz',**probs,labels=y[ix],indices=ix,groups=groups)
    return rows
