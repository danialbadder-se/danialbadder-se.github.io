"""Fixed, explicit fourteen-observation ontology and audited dataset adapters."""
from __future__ import annotations
import csv,gzip,hashlib,json,logging,re
from pathlib import Path
from dataclasses import asdict
import numpy as np
from .iu_io import Study,load_studies,split_groups,dump_json,write_csv,file_hash

LABELS=['Atelectasis','Cardiomegaly','Consolidation','Edema','Enlarged Cardiomediastinum',
        'Fracture','Lung Lesion','Lung Opacity','Pleural Effusion','Pneumonia',
        'Pneumothorax','Pleural Other','Support Devices','No Finding']
ALIASES={
 'Atelectasis':['atelectasis','pulmonary atelectasis'],
 'Cardiomegaly':['cardiomegaly'],
 'Consolidation':['consolidation','pulmonary consolidation'],
 'Edema':['edema','pulmonary edema'],
 'Enlarged Cardiomediastinum':['mediastinal enlargement','widened mediastinum'],
 'Fracture':['fractures, bone','fracture','fractures'],
 'Lung Lesion':['nodule','pulmonary nodule','mass','lung neoplasms'],
 'Lung Opacity':['opacity','lung opacity','pulmonary opacity','airspace disease','consolidation','infiltrate'],
 'Pleural Effusion':['effusion','pleural effusion'],
 'Pneumonia':['pneumonia'], 'Pneumothorax':['pneumothorax'],
 'Pleural Other':['pleural thickening','pleural calcification'],
 'Support Devices':['catheters, indwelling','tube, inserted','implanted medical device','medical device'],
 'No Finding':['normal'],
}


def mesh_positive(tags,label):
    """Preserve relation qualifiers; pulmonary atelectasis is an explicit alias.

    These are transparent cross-ontology weak mappings, not CheXpert labels
    recovered from radiologist-adjudicated images. No report keyword labelling.
    """
    for tag in tags:
        parts=[x.strip().lower() for x in tag.split('/')];root=parts[0]
        if root in ALIASES[label]:return True
        if label=='Pleural Other' and root=='thickening' and 'pleura' in parts:return True
        if label=='Enlarged Cardiomediastinum' and root=='mediastinum':
            # Local nodal/paratracheal/vascular prominence is not automatically
            # enlargement of the entire cardiomediastinal silhouette.
            if len(parts)>1 and parts[1] in {'prominent','enlarged','widened'}:return True
    return False


def weak_iu_labels(studies):
    result=np.zeros((len(studies),14),np.float32)
    for i,s in enumerate(studies):
        if s.tags and all(t.strip().lower()=='no indexing' for t in s.tags):result[i]=-1;continue
        for j,label in enumerate(LABELS):result[i,j]=float(mesh_positive(s.tags,label))
    return result


def read_rows(path):
    path=Path(path);opener=gzip.open if path.suffix=='.gz' else open
    with opener(path,'rt',encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))


def manifest_labels(row):
    # MIMIC uncertain(-1) AND unmentioned(blank) are masked by default.
    y=[]
    for label in LABELS:
        value=str(row.get(label,'')).strip()
        if value in {'','-1','-1.0','?','nan'}:y.append(-1.)
        elif value in {'0','0.0','1','1.0'}:y.append(float(value))
        else:raise ValueError(f'Invalid {label}: {value!r}')
    return y


def prepare(args):
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    if args.manifest:
        rows=read_rows(args.manifest)
        if not rows or not set(LABELS).issubset(rows[0]):raise ValueError('Manifest must contain all 14 exact observation columns')
        studies=[];targets=[];prescribed=[];alignment=[]
        for row in rows:
            paths=[str((Path(args.data_dir)/p).resolve()) if not Path(p).is_absolute() else p for p in row['image_paths'].split('|') if p]
            if any(not Path(p).is_file() for p in paths):raise FileNotFoundError(f"Missing image in {row['study_id']}")
            report=row.get('report','')
            if not report and row.get('report_path'):report=Path(row['report_path']).read_text(encoding='utf-8-sig')
            patient=str(row.get('subject_id',row.get('patient_id',''))).strip()
            if not patient:raise ValueError('MIMIC/generic manifest requires subject_id or patient_id')
            studies.append(Study(str(row['study_id']),paths,report,patient_id=patient,group='patient_'+patient))
            targets.append(manifest_labels(row));prescribed.append(row.get('split',''))
            alignment.append(float(row.get('pair_concordant','-1') or '-1') if 'pair_concordant' in rows[0] else 1.)
        if len({s.study_id for s in studies})!=len(studies):raise ValueError('Manifest must have one row per study, not one row per image')
        y=np.asarray(targets,np.float32)
        if all(prescribed):
            splits=np.array([{'validate':'val','validation':'val'}.get(v,v) for v in prescribed],dtype='U16')
            if not set(splits).issubset({'train','val','cal','test'}):raise ValueError('Invalid prescribed split')
            if 'cal' not in splits:
                train_groups=sorted({s.group for s,p in zip(studies,splits) if p=='train'})
                rng=np.random.default_rng(args.split_seed);rng.shuffle(train_groups)
                held=set(train_groups[:max(1,int(.1*len(train_groups)))])
                for i,s in enumerate(studies):
                    if s.group in held and splits[i]=='train':splits[i]='cal'
        else:splits=split_groups(studies,args.split_seed).astype('U16')
        source='caller_authorized_manifest';provenance='Manifest labels; uncertain/unmentioned masked. Provenance must be documented by caller.'
    elif args.reuse_iu_index:
        prior=Path(args.reuse_iu_index)
        studies=[Study(**s) for s in json.loads((prior/'studies_private.json').read_text())]
        if Path(json.loads((prior/'compatibility.json').read_text())['dataset_root']).resolve()!=Path(args.data_dir).resolve():raise ValueError('Reuse index belongs to another root')
        # Reuse verified image indexing ONLY, not v2 label arrays or checkpoints.
        splits=split_groups(studies,args.split_seed).astype('U16');y=weak_iu_labels(studies)
        source='open_i_mesh_14';provenance='Report-derived MeSH, transparently mapped weak labels; unannotated observations are weak negatives; No Finding requires normal annotation.'
    else:
        a=type('Args',(),{'data_dir':args.data_dir,'manifest':None})()
        studies,audit=load_studies(a);splits=split_groups(studies,args.split_seed).astype('U16')
        y=weak_iu_labels(studies);source='open_i_mesh_14'
        provenance='Report-derived MeSH, weak ontology mapping; not independent diagnostic labels.'
    groups={}
    hash_groups={}
    for s,p in zip(studies,splits):
        groups.setdefault(s.group,set()).add(str(p))
        # For manifest inputs, additionally reject byte-identical images that
        # cross partitions rather than allowing patient grouping to miss them.
        if args.manifest:
            for image in s.images:hash_groups.setdefault(file_hash(image),set()).add(str(p))
    if any(len(v)>1 for v in groups.values()) or any(len(v)>1 for v in hash_groups.values()):raise ValueError('Patient/image group leaks across prescribed splits')
    paired=np.array([bool(s.images) and bool(s.report.strip()) for s in studies])
    analysis=splits.copy();analysis[~paired]='excluded'
    train=y[analysis=='train'];pos=(train==1).sum(0);neg=(train==0).sum(0)
    pair_concordant=np.asarray(alignment,np.float32) if args.manifest else np.ones(len(studies),np.float32)
    if not np.isin(pair_concordant,[-1,0,1]).all():raise ValueError('pair_concordant must be 1(concordant),0(conflict),-1/blank(unknown)')
    np.save(out/'pair_concordant.npy',pair_concordant)
    active=(pos>=args.min_support)&(neg>=args.min_support)
    if not active.any():raise ValueError('No label has adequate TRAIN support')
    # Unsupported outputs remain unknown/abstaining, never fabricated classifiers.
    y[:,~active]=-1
    support=[{'label':label,'train_positive':int(pos[j]),'train_negative':int(neg[j]),'trained':bool(active[j]),
              'test_positive':int((y[analysis=='test',j]==1).sum()),'test_negative':int((y[analysis=='test',j]==0).sum())} for j,label in enumerate(LABELS)]
    dump_json(out/'ontology.json',{'labels':LABELS,'aliases':ALIASES,'type':'CheXpert-compatible 14 observations; No Finding and Support Devices are not pathologies','mapping':'OpenI cross-ontology weak mapping, not a replacement for official CheXpert labels'})
    dump_json(out/'support.json',support);dump_json(out/'studies_private.json',[asdict(s) for s in studies])
    np.save(out/'labels.npy',y);np.save(out/'split.npy',analysis);np.save(out/'active_labels.npy',active)
    rows=[{'study_id':s.study_id,'group':s.group,'split':str(analysis[i]),'images':[Path(p).name for p in s.images],
           'report_sha256':hashlib.sha256(s.report.encode()).hexdigest(),'labels':y[i].tolist()} for i,s in enumerate(studies)]
    signature=hashlib.sha256(json.dumps(rows,sort_keys=True).encode()).hexdigest()
    dump_json(out/'dataset_manifest.json',{'signature':signature,'source':source,'label_provenance':provenance,'studies':rows})
    dump_json(out/'population.json',{'studies':len(studies),'paired':int(paired.sum()),'splits':{k:int((analysis==k).sum()) for k in np.unique(analysis)},
        'trained_observations':int(active.sum()),'alignment_policy':'Native pairs weakly assumed concordant when pair_concordant column absent; explicit 0/-1 pairs excluded from MSE.',
        'original_atelectasis_mapping_fixed':int(sum(mesh_positive(s.tags,'Atelectasis') for s in studies)) if not args.manifest else None})
    logging.info('Prepared %d studies; %d/14 TRAIN-supported observations',len(studies),active.sum())
    return studies,analysis,y,active


def build_mimic(args):
    """Prepare one-study rows from caller-provided, authorized official files."""
    split_rows=read_rows(args.split_file);labels={r['study_id']:r for r in read_rows(args.label_file)}
    by_study={}
    for r in split_rows:by_study.setdefault((r['subject_id'],r['study_id'],r['split']),[]).append(r['dicom_id'])
    rows=[]
    for (subject,study,split),dicoms in by_study.items():
        relative=Path('files')/('p'+subject[:2])/('p'+subject)/('s'+study)
        images=[str((Path(args.data_dir)/relative/(d+'.jpg')).resolve()) for d in sorted(dicoms)]
        report_path=Path(args.reports_dir)/'files'/('p'+subject[:2])/('p'+subject)/('s'+study+'.txt')
        if not report_path.exists():report_path=Path(args.reports_dir)/('p'+subject[:2])/('p'+subject)/('s'+study+'.txt')
        if not report_path.is_file() or not all(Path(p).is_file() for p in images):continue
        if study not in labels:continue
        report=report_path.read_text(encoding='utf-8')
        sections=re.findall(r'(?:FINDINGS|IMPRESSION)\s*:\s*(.*?)(?=\n[A-Z][A-Z /]{2,}:|\Z)',report,flags=re.S)
        text=' '.join(s.strip() for s in sections) if sections else report.strip()
        rows.append({'study_id':study,'subject_id':subject,'split':split,'image_paths':'|'.join(images),
                     'report':text,**{label:labels[study].get(label,'') for label in LABELS}})
    if not rows:raise ValueError('No complete authorized MIMIC studies matched; check paths and official tables')
    write_csv(args.output,rows)
    logging.info('Wrote %d MIMIC study rows; skipped incomplete local studies (partial local release)',len(rows))
