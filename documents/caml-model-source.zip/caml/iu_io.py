from __future__ import annotations

import argparse
import copy
import csv
import hashlib
import json
import logging
import math
import os
from pathlib import Path
import random
import re
import sys
import time
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Any

import numpy as np

VERSION = "CAML-1.0.0"
DEFAULT_TEXT_MODEL = "microsoft/BiomedNLP-BiomedBERT-base-uncased-abstract-fulltext"
MODES = ("image", "text", "concat", "dynamic")
DISCLAIMER = (
    "RESEARCH ONLY: not clinically validated. MeSH labels are report-derived; "
    "text-input scores measure reconstruction of report annotations, not "
    "independent diagnostic accuracy. Unannotated concepts are weak negatives. "
    "Reliability, MC-dropout uncertainty and disagreement are model proxies. "
    "A mismatch flag does not establish which input is correct."
)


def dump_json(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    def native(x):
        if isinstance(x, np.ndarray):
            return x.tolist()
        if isinstance(x, np.generic):
            return x.item()
        if isinstance(x, Path):
            return str(x)
        raise TypeError(type(x).__name__)
    Path(path).write_text(json.dumps(value, indent=2, default=native, allow_nan=False), encoding="utf-8")


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_csv(path, rows):
    if not rows:
        return
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with Path(path).open("w", newline="", encoding="utf-8") as f:
        keys = list(dict.fromkeys(key for row in rows for key in row))
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)


def log_setup(out):
    Path(out).mkdir(parents=True, exist_ok=True)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(message)s",
                        handlers=[logging.StreamHandler(sys.stdout),
                                  logging.FileHandler(Path(out) / "run.log", encoding="utf-8")], force=True)


def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    import torch
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.set_num_threads(max(1, min(4, os.cpu_count() or 1)))
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def device_for(choice):
    import torch
    if choice == "auto":
        choice = "cuda" if torch.cuda.is_available() else "cpu"
    if choice == "cuda" and not torch.cuda.is_available():
        raise ValueError("CUDA GPU unavailable. Use --device cpu or run on a GPU host.")
    return torch.device(choice)


def file_hash(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def uid(value):
    text = str(value).strip()
    return re.sub(r"\.0$", "", text)


@dataclass
class Study:
    study_id: str
    images: list[str]
    report: str
    tags: list[str] = field(default_factory=list)
    patient_id: str = ""
    explicit_labels: dict[str, float] = field(default_factory=dict)
    group: str = ""


def image_index(root):
    from PIL import Image
    paths = sorted(p for p in root.rglob("*") if p.suffix.lower() in {".png", ".jpg", ".jpeg"})
    if not paths:
        raise ValueError("No PNG/JPG images found. Extract the image archive first. DICOM-only input is not supported; use the Open-I PNG release.")
    index, hashes, duplicate_names = {}, {}, []
    for number, path in enumerate(paths, 1):
        if number % 500 == 0:
            logging.info("Hashing image %d/%d", number, len(paths))
        digest = file_hash(path)
        hashes[str(path)] = digest
        for key in (path.name.casefold(), path.stem.casefold()):
            if key in index and hashes[str(index[key])] != digest:
                duplicate_names.append(key)
            else:
                index[key] = path
    if duplicate_names:
        raise ValueError("Ambiguous image filenames with different content: " + ", ".join(sorted(set(duplicate_names))[:5]))
    bad = []
    for number, path in enumerate(paths, 1):
        if number % 500 == 0:
            logging.info("Verifying image %d/%d", number, len(paths))
        try:
            with Image.open(path) as im:
                im.verify()
        except Exception as e:
            bad.append({"path": str(path), "error": str(e)})
    if bad:
        raise ValueError(f"Found {len(bad)} unreadable images; first: {bad[0]}. Remove/replace these files before running.")
    return index, hashes


def resolve_image(name, root, index):
    name = str(name).strip().replace("\\", "/")
    candidate = Path(name)
    if not candidate.is_absolute():
        candidate = root / candidate
    if candidate.is_file():
        return str(candidate.resolve())
    found = index.get(Path(name).name.casefold()) or index.get(Path(name).stem.casefold())
    return str(found.resolve()) if found else None


def csv_rows(path):
    with Path(path).open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def load_studies(args):
    root = Path(args.data_dir).expanduser().resolve()
    if not root.is_dir():
        raise ValueError(f"Dataset folder does not exist: {root}")
    logging.info("Checking images, filenames and SHA-256 duplicate groups...")
    index, hashes = image_index(root)
    studies, missing, excluded, source, annotations = [], [], [], "", Counter()
    if args.manifest:
        source = "explicit_label_manifest"
        rows = csv_rows(args.manifest)
        if not rows or not {"study_id", "image_paths", "report"}.issubset(rows[0]):
            raise ValueError("Manifest needs study_id,image_paths,report plus label_* columns. Use | between image paths.")
        cols = [k for k in rows[0] if k.startswith("label_")]
        if not cols:
            raise ValueError("Manifest has no label_* columns. Use 0, 1, or blank for unknown.")
        for row in rows:
            paths = [resolve_image(x, root, index) for x in row["image_paths"].split("|") if x.strip()]
            labels = {}
            for key in cols:
                v = row.get(key, "").strip()
                if v in {"", "?", "-1", "nan"}:
                    labels[key[6:]] = -1.0
                elif v in {"0", "0.0", "1", "1.0"}:
                    labels[key[6:]] = float(v)
                else:
                    raise ValueError(f"Invalid label {key}={v!r} in study {row['study_id']}")
            if any(x is None for x in paths):
                missing.append(row["study_id"])
                continue
            studies.append(Study(uid(row["study_id"]), paths, row.get("report", "").strip(),
                                 patient_id=row.get("patient_id", "").strip(), explicit_labels=labels))
    else:
        xml_files = sorted(root.rglob("*.xml"))
        report_csvs = sorted(root.rglob("indiana_reports.csv"))
        projection_csvs = sorted(root.rglob("indiana_projections.csv"))
        if xml_files:
            source = "openi_xml_mesh"
            for path in xml_files:
                data = path.read_text(encoding="utf-8", errors="strict")
                if re.search(r"<!\s*(?:DOCTYPE|ENTITY)", data, flags=re.I):
                    raise ValueError(f"Unexpected XML entity/DOCTYPE in {path}; not accepted.")
                tree = ET.fromstring(data)
                id_node = tree.find(".//uId")
                study_id = id_node.get("id", path.stem) if id_node is not None else path.stem
                # IDs come from explicit parentImage references, not filename guesses.
                refs = [n.get("id", "") for n in tree.findall(".//parentImage")]
                paths = [resolve_image(x, root, index) for x in refs if x]
                if not paths or any(x is None for x in paths):
                    missing.append(study_id)
                    continue
                report = " ".join((n.text or "").strip() for n in tree.findall(".//AbstractText")
                                  if n.get("Label", "").casefold() in {"findings", "impression"})
                tags = [(n.text or "").strip() for n in tree.findall(".//MeSH/major") if (n.text or "").strip()]
                if not tags:
                    excluded.append({"study_id": study_id, "reason": "no_manual_MeSH_annotations"})
                    continue
                annotations["manual_MeSH"] += 1
                studies.append(Study(uid(study_id), sorted(set(paths)), report, tags))
        elif report_csvs and projection_csvs:
            if len(report_csvs) != 1 or len(projection_csvs) != 1:
                raise ValueError("Multiple Indiana CSV copies found; keep only the intended release under --data-dir.")
            source = "indiana_csv_mesh"
            projections = defaultdict(list)
            for row in csv_rows(projection_csvs[0]):
                projections[uid(row["uid"])].append(row["filename"])
            for row in csv_rows(report_csvs[0]):
                study_id = uid(row["uid"])
                paths = [resolve_image(x, root, index) for x in projections[study_id]]
                if not paths or any(x is None for x in paths):
                    missing.append(study_id)
                    continue
                mesh_field = row.get("MeSH", row.get("mesh", ""))
                # MeSH phrases can contain commas; only semicolons separate concepts.
                tags = [x.strip() for x in mesh_field.split(";") if x.strip()]
                if not tags:
                    excluded.append({"study_id": study_id, "reason": "no_MeSH_annotations"})
                    continue
                report = " ".join(row.get(k, "").strip() for k in ("findings", "impression")).strip()
                studies.append(Study(study_id, sorted(set(paths)), report, tags,
                                     patient_id=row.get("patient_id", "").strip()))
        else:
            raise ValueError("Could not find original Open-I XML reports or both indiana_reports.csv and indiana_projections.csv. Extract reports too, or supply --manifest labelled.csv.")
    seen = set()
    valid = []
    for study in studies:
        if study.study_id in seen:
            raise ValueError(f"Duplicate study ID: {study.study_id}")
        seen.add(study.study_id)
        if study.images or study.report:
            valid.append(study)
    studies = valid
    if not studies:
        raise ValueError("No usable labelled studies matched. Check that images and reports are from the same release.")
    # Union shared patient IDs AND byte-identical images before splitting.
    parent = list(range(len(studies)))
    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    owners = {}
    for i, study in enumerate(studies):
        keys = ["image:" + (hashes[p] if p in hashes else file_hash(p)) for p in study.images]
        if study.patient_id:
            keys.append("patient:" + study.patient_id)
        for key in keys:
            if key in owners:
                parent[find(i)] = find(owners[key])
            else:
                owners[key] = i
    for i, study in enumerate(studies):
        study.group = f"group_{find(i):06d}"
    audit = {
        "source_format": source, "dataset_root": str(root), "usable_studies": len(studies),
        "linked_images": len(set(p for s in studies for p in s.images)),
        "report_present": sum(bool(s.report) for s in studies),
        "multiple_image_studies": sum(len(s.images) > 1 for s in studies),
        "unmatched_study_ids": missing, "excluded": excluded,
        "leakage_groups": len(set(s.group for s in studies)),
        "patient_ids_available": sum(bool(s.patient_id) for s in studies),
        "grouping_note": "Patient IDs where supplied, plus shared byte-identical images. Otherwise study-level grouping; patient identities cannot be independently reconstructed.",
        "label_provenance": ("Caller-supplied labels; independence from report not verified." if args.manifest else "Report-derived MeSH annotations; no independent image-adjudicated diagnosis labels."),
        "weak_negative_policy": "For MeSH input, unannotated supported findings are coded 0 (weak negatives). For manifest input, blank/-1 means unknown and is masked.",
        "limitations": DISCLAIMER,
    }
    return studies, audit


def split_groups(studies, seed):
    groups = sorted({s.group for s in studies})
    if len(groups) < 20:
        raise ValueError("Need at least 20 independent groups for train/validation/calibration/test. Add data; do not use smoke-test scores as evidence.")
    rng = np.random.default_rng(seed)
    rng.shuffle(groups)
    a, b, c = int(.7 * len(groups)), int(.8 * len(groups)), int(.9 * len(groups))
    mapping = {g: name for name, subset in zip(("train", "val", "cal", "test"),
               (groups[:a], groups[a:b], groups[b:c], groups[c:])) for g in subset}
    splits = np.asarray([mapping[s.group] for s in studies])
    return splits


