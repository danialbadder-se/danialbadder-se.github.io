from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import torch
from scipy.special import expit,logit
from .engine import restore,infer,triage
from .encoders import Encoders,pooled
from .iu_io import dump_json,seed_all


def predict(args):
    root=Path(args.run_dir);protocol=json.loads((root/'protocol.json').read_text());seed_all(42)
    images=args.image;report=Path(args.report_file).read_text(encoding='utf-8-sig').strip() if args.report_file else ''
    if not images and not report:raise ValueError('Provide at least an image or nonempty report')
    if len(images)>2:raise ValueError('At most two views: frontal first, lateral second')
    enc=Encoders(root/'shared/encoders',args.device,max_length=protocol['max_length'])
    im=np.zeros((1,32,1024),np.float16);mi=np.zeros((1,32),bool)
    for v,p in enumerate(images):im[0,v*16:(v+1)*16]=enc.images([p])[0];mi[0,v*16:(v+1)*16]=True
    text,mt=enc.reports([report])
    if not report:text[:]=0;mt[:]=False
    cache={'image':im,'imask':mi,'text':text,'tmask':mt};prob=[];us=[];mis=[];alphas=[];conflict=[];cosine=[];discrepancy=[];weights=[];decisions=[];attentions=[]
    active=np.load(root/'active_labels.npy')
    for seed in protocol['seeds']:
        folder=root/f'seed_{seed}';model,norm,cp=restore(folder/'full.pt',args.device)
        cal=json.loads((folder/'full_metrics.json').read_text())['calibration']
        raw=infer(model,cache,np.array([0]),norm,args.device,1)
        p=expit(logit(raw['probability'].clip(1e-7,1-1e-7))/cal['temperature']);prob.append(p)
        us.append(raw['vacuity']);mis.append(raw['epistemic_mi_proxy']);alphas.append(raw['alpha']);conflict.append(raw['conflict'])
        cosine.append(raw['cosine']);discrepancy.append(raw['discrepancy']);weights.append(raw['weights'])
        decisions.append(triage(p,raw['vacuity'],raw['conflict'],raw['available'],cal['triage'],active)[0])
        if images and report:
            from .engine import batch
            with torch.inference_mode():a=model(*batch(cache,np.array([0]),norm,args.device),attention=True)['attention'][0].cpu().numpy()
            attentions.append(a[np.asarray(mt[0])].mean(0).reshape(2,4,4))
    p=np.mean(prob,axis=0)[0];u=np.mean(us,axis=0)[0];mi_proxy=np.mean(mis,axis=0)[0];alpha=np.mean(alphas,axis=0)[0]
    # Conservative category aggregation; all seeds use VAL-derived settings.
    triage_level='High Uncertainty / Conflict' if 'High Uncertainty / Conflict' in decisions else ('High Confidence' if all(v=='High Confidence' for v in decisions) else 'Moderate Confidence')
    result={'model':'CAML-Net','version':'1.0.0','research_only':True,'available':{'image':bool(images),'report':bool(report)},
            'triage':triage_level,'per_seed_triage':decisions,
            'conflict_score':float(np.mean(conflict)) if images and report else None,
            'shared_cosine_similarity':float(np.mean(cosine)) if images and report else None,
            'shared_rms_discrepancy':float(np.mean(discrepancy)) if images and report else None,
            'uncertainty_scope':'Raw subjective-logic vacuity and Beta mutual-information proxies; held-out temperature calibrates disease probabilities, not epistemic truth.',
            'qualification':'Open-I/MIMIC labels are report-derived; no verified clinical contradiction or hallucination-prevention guarantee. Shared/private orthogonality is linear, not proof of causal disentanglement.',
            'predictions':[{'label':label,'trained':bool(active[j]),'calibrated_probability':float(p[j]) if active[j] else None,
              'positive_at_0_5':bool(p[j]>=.5) if active[j] else None,'evidential_vacuity':float(u[j]) if active[j] else None,
              'epistemic_mi_proxy':float(mi_proxy[j]) if active[j] else None,
              'mean_alpha_negative_positive':alpha[j].tolist() if active[j] else None,
              'image_text_gate_weights':np.mean(weights,axis=0)[0,j].tolist() if active[j] else None} for j,label in enumerate(protocol['labels'])]}
    dump_json(args.output,result)
    if attentions:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        from PIL import Image,ImageOps
        heat=np.mean(attentions,axis=0);fig,axes=plt.subplots(1,len(images),figsize=(4*len(images),4),squeeze=False)
        for v,path in enumerate(images):
            with Image.open(path) as img:background=ImageOps.pad(img.convert('RGB'),(224,224),Image.Resampling.BILINEAR,color=(124,116,104))
            axes[0,v].imshow(background);axes[0,v].imshow(heat[v],extent=(0,224,224,0),cmap='inferno',alpha=.35)
            axes[0,v].set_title('CAML-Net cross-attention (descriptive)');axes[0,v].axis('off')
        fig.tight_layout();fig.savefig(Path(args.output).with_suffix('.attention.png'));plt.close(fig)
    print(f'CAML-Net prediction saved: {Path(args.output).resolve()}',flush=True)
