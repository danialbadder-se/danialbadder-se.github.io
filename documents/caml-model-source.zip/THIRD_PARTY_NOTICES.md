# Third-party models and data

DenseNet-121 image features use the official torchvision ImageNet-1K V1 weights;
the original classifier is discarded. Torchvision's license is retained in
`third_party/torchvision_LICENSE.txt`.

The text encoder/tokenizer is the publisher's
`dmis-lab/biobert-base-cased-v1.2` checkpoint. BioBERT's upstream repository
notice/license is retained unchanged in `third_party/BioBERT_LICENSE.txt`.
Sources: https://github.com/dmis-lab/biobert and
https://huggingface.co/dmis-lab/biobert-base-cased-v1.2 .
The package does not claim ownership of these pretrained assets. The exact
exported model/config/tokenizer hashes are recorded in the run folder.

Open-I public processed images/reports were obtained from
https://www.kaggle.com/datasets/raddar/chest-xrays-indiana-university .
The raw dataset and token cache are not redistributed here. MeSH target mapping
is a weak cross-ontology approximation, documented in `ontology.json`.

No MIMIC-CXR images, reports or credentials are included. Access and downstream
processing/export must follow the dataset's authorized-use conditions:
https://physionet.org/content/mimic-cxr-jpg/2.1.0/ .

Other dependencies retain their upstream licenses. The newly trained CAML-Net
research heads and their actual limitations are described in the README and
results report.
