const backendInput = document.getElementById("backendUrl");
const textInput = document.getElementById("textInput");
const useSelectionBtn = document.getElementById("useSelectionBtn");
const analyzePageTextBtn = document.getElementById("analyzePageTextBtn");
const analyzeUrlBtn = document.getElementById("analyzeUrlBtn");
const analyzeTextBtn = document.getElementById("analyzeTextBtn");
const resultBox = document.getElementById("result");
const predictionEl = document.getElementById("prediction");
const confidenceEl = document.getElementById("confidence");
const realFakeEl = document.getElementById("realFake");
const extraEl = document.getElementById("extra");
const statusEl = document.getElementById("status");

const DEFAULT_BACKEND = "http://127.0.0.1:5000";

init();

async function init() {
  const saved = await chrome.storage.local.get(["backendUrl"]);
  backendInput.value = saved.backendUrl || DEFAULT_BACKEND;

  backendInput.addEventListener("change", async () => {
    await chrome.storage.local.set({ backendUrl: normalizeBaseUrl(backendInput.value) });
    backendInput.value = normalizeBaseUrl(backendInput.value);
  });

  useSelectionBtn.addEventListener("click", handleUseSelection);
  analyzePageTextBtn.addEventListener("click", handleAnalyzePageTextSource);
  analyzeUrlBtn.addEventListener("click", handleAnalyzeUrl);
  analyzeTextBtn.addEventListener("click", handleAnalyzeText);
}

function normalizeBaseUrl(url) {
  return (url || DEFAULT_BACKEND).trim().replace(/\/$/, "");
}

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs[0];
}

async function extractFromPage(mode) {
  const tab = await getActiveTab();
  if (!tab || !tab.id) {
    throw new Error("No active tab found.");
  }

  const injected = await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: (requestedMode) => {
      const selection = String(window.getSelection ? window.getSelection().toString() : "").trim();
      const pageText = (document.body?.innerText || "").replace(/\s+/g, " ").trim();
      const title = document.title || "";
      const url = window.location.href || "";

      if (requestedMode === "selection") {
        return { value: selection, title, url };
      }
      return { value: pageText.slice(0, 12000), title, url };
    },
    args: [mode]
  });

  return injected?.[0]?.result || { value: "", title: "", url: "" };
}

function setStatus(message, kind = "") {
  statusEl.textContent = message;
  statusEl.className = `status ${kind}`.trim();
}

function renderTextResult(data) {
  resultBox.classList.remove("hidden");
  predictionEl.textContent = `Prediction: ${data.prediction || "N/A"}`;
  confidenceEl.textContent = `Confidence: ${data.confidence ?? "N/A"}%`;
  realFakeEl.textContent = `Real: ${data.real_percentage ?? "N/A"}% | Fake: ${data.fake_percentage ?? "N/A"}%`;
  extraEl.textContent = `Words: ${data.word_count ?? "N/A"}`;
}

function renderUrlResult(data) {
  resultBox.classList.remove("hidden");
  predictionEl.textContent = `Domain: ${data.domain || "N/A"}`;
  confidenceEl.textContent = `Trust Score: ${data.trust_score ?? "N/A"}`;
  realFakeEl.textContent = `Type: ${data.source_type || "N/A"} | SSL: ${data.ssl_secured ? "Yes" : "No"}`;
  extraEl.textContent = data.analysis || "";
}

async function postJson(path, payload) {
  const base = normalizeBaseUrl(backendInput.value);
  const response = await fetch(`${base}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });

  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(data.error || data.message || `Request failed: ${response.status}`);
  }
  return data;
}

async function handleUseSelection() {
  try {
    setStatus("Reading selected text from page...");
    const info = await extractFromPage("selection");
    if (!info.value) {
      setStatus("No selected text found. Highlight text on page first.", "warn");
      return;
    }
    textInput.value = info.value;
    setStatus("Selected text loaded.", "ok");
  } catch (error) {
    setStatus(`Error: ${error.message}`, "bad");
  }
}

async function handleAnalyzePageTextSource() {
  try {
    setStatus("Extracting page text...");
    const info = await extractFromPage("page");
    if (!info.value) {
      setStatus("Could not read page text.", "warn");
      return;
    }
    textInput.value = info.value;
    setStatus("Page text loaded. Running analysis...");
    await handleAnalyzeText();
  } catch (error) {
    setStatus(`Error: ${error.message}`, "bad");
  }
}

async function handleAnalyzeText() {
  const text = textInput.value.trim();
  if (text.length < 10) {
    setStatus("Please enter at least 10 characters.", "warn");
    return;
  }

  try {
    setStatus("Analyzing text...");
    const data = await postJson("/api/check", { text });
    renderTextResult(data);
    setStatus("Text analysis complete.", "ok");
  } catch (error) {
    setStatus(`Backend error: ${error.message}`, "bad");
  }
}

async function handleAnalyzeUrl() {
  try {
    setStatus("Reading current page URL...");
    const tab = await getActiveTab();
    const currentUrl = tab?.url;
    if (!currentUrl) {
      setStatus("Could not detect active page URL.", "warn");
      return;
    }

    setStatus("Checking source credibility...");
    const data = await postJson("/api/check-url", { url: currentUrl });
    renderUrlResult(data);
    setStatus("URL credibility check complete.", "ok");
  } catch (error) {
    setStatus(`Backend error: ${error.message}`, "bad");
  }
}
