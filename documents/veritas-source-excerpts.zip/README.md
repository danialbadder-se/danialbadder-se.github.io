# VERITAS · selected source

The project is called VERITAS in the academic write-up, VeriCleri in the supplied web interface, TruthLens in the setup guide, and TruthDetect in the extension. These selected implementation files accompany the portfolio case study. The model checkpoint and Flask server are required to run the full application.
