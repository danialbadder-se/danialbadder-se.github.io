    def predict(self, text):
        if self.word_pipeline is None and self.char_pipeline is None:
            return None

        try:
            probabilities_list = []
            if self.word_pipeline is not None:
                probabilities_list.append(self.word_pipeline.predict_proba([text])[0])
            if self.char_pipeline is not None:
                probabilities_list.append(self.char_pipeline.predict_proba([text])[0])

            if not probabilities_list:
                return None

            probabilities = sum(probabilities_list) / len(probabilities_list)
            fake_probability = float(probabilities[1] * 100)
            real_probability = float(probabilities[0] * 100)

            thresholds = self.metrics.get('decision_thresholds', {})
            real_threshold = float(thresholds.get('real_threshold', 0.45))
            fake_threshold = float(thresholds.get('fake_threshold', 0.55))

            fake_probability_raw = float(probabilities[1])
            if fake_probability_raw >= fake_threshold:
                prediction = 'FAKE'
                margin = (fake_probability_raw - fake_threshold) / max(1.0 - fake_threshold, 1e-6)
                confidence = 60 + (margin * 38)
            elif fake_probability_raw <= real_threshold:
                prediction = 'REAL'
                margin = (real_threshold - fake_probability_raw) / max(real_threshold, 1e-6)
                confidence = 60 + (margin * 38)
            else:
                prediction = 'UNCERTAIN'
                midpoint = (real_threshold + fake_threshold) / 2.0
                half_band = max((fake_threshold - real_threshold) / 2.0, 1e-6)
                distance = abs(fake_probability_raw - midpoint)
                confidence = 50 + max(0.0, (1 - (distance / half_band)) * 12)

            return {
                'prediction': prediction,
                'confidence': round(min(confidence, 99), 2),
                'real_percentage': round(real_probability, 2),
                'fake_percentage': round(fake_probability, 2),
                'thresholds': {
                    'real_threshold': round(real_threshold * 100, 2),
                    'fake_threshold': round(fake_threshold * 100, 2),
                },
                'model': 'ensemble_word_char_logreg',
            }
        except Exception as error:
            self.last_error = f"Prediction failed: {str(error)}"
            return None

